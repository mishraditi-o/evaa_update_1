import test from 'node:test';
import assert from 'node:assert/strict';

import { buildAnalysisReport, renderReportPdf } from '../index.js';

const NOW = new Date('2026-10-22T07:00:00.000Z');

// A dataset as the EVAA backend returns it, with the engine's metadata report.
function dataset(overrides = {}, report = {}) {
  return {
    id: 'ds-1',
    name: 'recording',
    fileName: 'recording.csv',
    fileFormat: 'CSV',
    status: 'READY',
    createdAt: '2026-10-22T06:00:00.000Z',
    metadata: {
      eventCount: '1000',
      sensorWidth: 640,
      sensorHeight: 480,
      eventRate: 250000,
      customMetadata: {
        durationUs: 4000,
        skippedRows: 0,
        benchmark: {
          total: { durationMs: 2000, eventsPerSecond: 500 },
          memory: { peakMB: 199.68 },
          outputFiles: { hdf5MB: 0.25, parquetMB: 0.66 }
        },
        report: {
          eventCount: 1000,
          validEventCount: 1000,
          invalidEventCount: 0,
          sensor: {
            width: 640,
            height: 480,
            resolutionSource: 'inferred',
            resolutionVerified: false,
            activePixelCount: 400,
            sensorPixelCount: 307200
          },
          timestamps: {
            unit: 'microseconds',
            durationSeconds: 0.004,
            sortedInput: true
          },
          polarity: {
            positiveEventCount: 600,
            negativeEventCount: 0,
            zeroPolarityCount: 400
          },
          analytics: {
            eventRatePerSecond: 250000,
            spatialCoveragePercent: 0.13
          },
          dataQuality: { status: 'valid', warnings: [] },
          performance: {
            parsingDurationMs: 500,
            hdf5WritingDurationMs: 300,
            parquetWritingDurationMs: 700,
            totalIngestionDurationMs: 2000,
            eventsProcessedPerSecond: 500
          },
          ...report
        }
      }
    },
    ...overrides
  };
}

const withoutReport = () => {
  const d = dataset();
  delete d.metadata.customMetadata.report;
  return d;
};

const isPdf = (buffer) => buffer.subarray(0, 5).toString() === '%PDF-';

test('report: reads the measured values', () => {
  const r = buildAnalysisReport(dataset(), NOW);
  assert.equal(r.detailed, true);
  assert.equal(r.summary.eventCount, 1000);
  assert.equal(r.summary.sensorWidth, 640);
  assert.equal(r.summary.durationSeconds, 0.004);
  assert.equal(r.summary.resolutionSource, 'estimated');
  assert.equal(r.quality.completenessPercent, 100);
  assert.equal(r.sensor.coveragePercent, 0.13);
  assert.equal(r.sensor.sparsityPercent, 99.87);
  assert.equal(r.sensor.eventsPerActivePixel, 2.5);
  assert.equal(r.performance.processingSeconds, 2);
  assert.equal(r.performance.processingToRecordingRatio, 500);
  assert.equal(r.performance.peakMemoryMB, 200);
  assert.equal(r.performance.outputSizeMB, 0.91);
});

test('report: a 0/1 polarity file has ON = 1 and OFF = 0', () => {
  const r = buildAnalysisReport(dataset(), NOW);
  assert.equal(r.sensor.onEvents, 600);
  assert.equal(r.sensor.offEvents, 400);
  assert.equal(r.sensor.onPercent, 60);
  assert.match(r.sensor.polarityNote, /1 \(ON\) \/ 0 \(OFF\)/);
});

test('report: a +1 / -1 polarity file has ON = +1 and OFF = -1', () => {
  const r = buildAnalysisReport(
    dataset(
      {},
      {
        polarity: {
          positiveEventCount: 700,
          negativeEventCount: 300,
          zeroPolarityCount: 0
        }
      }
    ),
    NOW
  );
  assert.equal(r.sensor.onEvents, 700);
  assert.equal(r.sensor.offEvents, 300);
  assert.match(r.sensor.polarityNote, /\+1 \/ -1/);
});

test('report: invalid events and unsorted input become findings', () => {
  const r = buildAnalysisReport(
    dataset(
      {},
      {
        validEventCount: 990,
        invalidEventCount: 10,
        timestamps: {
          unit: 'microseconds',
          durationSeconds: 0.004,
          sortedInput: false
        }
      }
    ),
    NOW
  );
  assert.equal(r.quality.completenessPercent, 99);
  const text = r.findings.map((f) => f.text).join(' ');
  assert.match(text, /10 events/);
  assert.match(text, /not in time order/);
  assert.ok(r.findings.some((f) => f.level === 'warning'));
});

test('report: a clean verified file gets a single "all clear" finding', () => {
  const r = buildAnalysisReport(
    dataset(
      {},
      {
        sensor: {
          width: 640,
          height: 480,
          resolutionVerified: true,
          activePixelCount: 150000,
          sensorPixelCount: 307200
        },
        analytics: { eventRatePerSecond: 250000, spatialCoveragePercent: 48.8 }
      }
    ),
    NOW
  );
  assert.equal(r.findings.length, 1);
  assert.equal(r.findings[0].level, 'ok');
});

test('report: works for a dataset without the detailed report', () => {
  const r = buildAnalysisReport(withoutReport(), NOW);
  assert.equal(r.detailed, false);
  assert.equal(r.summary.eventCount, 1000);
  assert.equal(r.summary.sensorWidth, 640);
  assert.equal(r.summary.resolutionSource, null);
  assert.equal(r.quality.validationStatus, null);
  assert.equal(r.sensor.coveragePercent, null);
  assert.match(r.findings[0].text, /converted before/);
});

test('report: does not throw for a dataset without metadata', () => {
  const r = buildAnalysisReport(
    { id: 'x', name: 'n', fileName: 'f.csv', fileFormat: 'CSV' },
    NOW
  );
  assert.equal(r.summary.eventCount, null);
  assert.equal(r.detailed, false);
});

test('pdf: produces a PDF with the embedded font', async () => {
  const pdf = await renderReportPdf(buildAnalysisReport(dataset(), NOW));
  assert.ok(isPdf(pdf));
  assert.ok(pdf.length > 5000);
  assert.ok(pdf.includes(Buffer.from('Inter')), 'Inter font is embedded');
});

test('pdf: produces a PDF for a dataset without the detailed report', async () => {
  const pdf = await renderReportPdf(buildAnalysisReport(withoutReport(), NOW));
  assert.ok(isPdf(pdf));
});

test('pdf: draws the charts when they are given', async () => {
  const report = buildAnalysisReport(dataset(), NOW);
  const plain = await renderReportPdf(report);
  const charts = {
    eventRate: {
      binUs: 100,
      on: [10, 40, 30, 80, 20],
      off: [5, 20, 25, 60, 10]
    },
    heatmap: {
      gridW: 4,
      gridH: 3,
      max: 9,
      values: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1]
    }
  };
  const withCharts = await renderReportPdf(report, { charts });
  assert.ok(isPdf(withCharts));
  assert.ok(withCharts.length > plain.length);
});

test('pdf: handles many findings and long text without crashing', async () => {
  const report = buildAnalysisReport(dataset(), NOW);
  report.findings = Array.from({ length: 30 }, (_, i) => ({
    level: ['ok', 'info', 'warning'][i % 3],
    text:
      `Finding ${i}: ` +
      'a long sentence that has to wrap over several lines. '.repeat(4)
  }));
  const pdf = await renderReportPdf(report);
  assert.ok(isPdf(pdf));
});