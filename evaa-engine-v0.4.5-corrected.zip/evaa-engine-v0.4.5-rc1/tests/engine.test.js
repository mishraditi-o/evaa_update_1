import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { ingest, visualize } from '../index.js';
import { parseCsv } from '../ingest/parsers/csv.parser.js';
import { parseTxt } from '../ingest/parsers/txt.parser.js';
import { parseNpy } from '../ingest/parsers/npy.parser.js';
import { parseH5 } from '../ingest/parsers/h5.parser.js';
import { validateEvents } from '../utils/validation.js';
import { writeHdf5 } from '../writers/hdf5.writer.js';

/*
 * EVAA engine tests. Run with:  npm test
 *
 * Every test file is created on the fly in a temporary folder, so these
 * tests need no sample files and leave nothing behind. Each test states
 * what it expects BEFORE it runs.
 */

const here = path.dirname(fileURLToPath(import.meta.url));
let dir;

before(async () => {
  dir = await fs.mkdtemp(path.join(os.tmpdir(), 'evaa-test-'));
});

after(async () => {
  await fs.rm(dir, { recursive: true, force: true });
});

// Writes a small text file and returns its path
async function textFile(name, content, encoding = 'utf8') {
  const file = path.join(dir, name);
  await fs.writeFile(file, content, encoding);
  return file;
}

// Builds the bytes of a NumPy .npy file (version 1.0)
function npyBytes(descr, shape, data, fortran = false) {
  const dims = shape.length === 1 ? `${shape[0]},` : shape.join(', ');
  let header = `{'descr': '${descr}', 'fortran_order': ${
    fortran ? 'True' : 'False'
  }, 'shape': (${dims}), }`;
  const pad = (64 - ((10 + header.length + 1) % 64)) % 64;
  header = header + ' '.repeat(pad) + '\n';

  const head = Buffer.alloc(10 + header.length);
  head.write('\x93NUMPY', 0, 'latin1');
  head[6] = 1;
  head[7] = 0;
  head.writeUInt16LE(header.length, 8);
  head.write(header, 10, 'latin1');

  return Buffer.concat([head, Buffer.from(data.buffer)]);
}

const ROWS = [
  [1, 1, 2, 1],
  [2, 3, 4, 0],
  [3, 5, 6, 1],
  [4, 7, 8, 0],
  [5, 9, 10, 1]
];

// ---------------------------------------------------------------- CSV

test('csv: BOM, scientific notation, empty cell and bad row', async () => {
  const file = await textFile(
    'bom.csv',
    '﻿t,x,y,p\n1e-3,1,2,1\n2e-3,3,4,0\nbad,1,2,1\n3e-3,,4,1\n4e-3,5,6,1\n'
  );
  const events = await parseCsv(file);

  assert.equal(events.length, 3);
  assert.equal(events.skippedRows, 2); // the 'bad' row and the empty cell
  assert.deepEqual(events[0], { t: 0.001, x: 1, y: 2, p: 1 });
});

test('csv: semicolon delimiter', async () => {
  const file = await textFile('semi.csv', 'timestamp;x;y;polarity\n10;1;2;1\n20;3;4;0\n');
  assert.equal((await parseCsv(file)).length, 2);
});

test('csv: no header, comment line first', async () => {
  const file = await textFile('nohdr.csv', '# comment\n10,1,2,1\n20,3,4,0\n');
  assert.equal((await parseCsv(file)).length, 2);
});

test('csv: Windows line endings', async () => {
  const file = await textFile('crlf.csv', 't,x,y,p\r\n1,1,2,1\r\n2,3,4,0\r\n');
  assert.equal((await parseCsv(file)).length, 2);
});

test('csv: unknown header is rejected with a clear message', async () => {
  const file = await textFile('bad.csv', 'a,b,c,d\n1,2,3,4\n');
  await assert.rejects(parseCsv(file), /must name the columns t, x, y, p/);
});

test('csv: empty file is rejected', async () => {
  const file = await textFile('empty.csv', '');
  await assert.rejects(parseCsv(file), /empty/);
});

// ---------------------------------------------------------------- TXT

test('txt: first row in scientific notation is data, not a header', async () => {
  const file = await textFile('sci.txt', '1.5e-3 1 2 1\n2.5e-3 3 4 0\n3e-3 5\n');
  const events = await parseTxt(file);

  assert.equal(events.length, 2);
  assert.equal(events.skippedRows, 1); // the short third row
  assert.equal(events[0].t, 0.0015);
});

test('txt: header in a comment line', async () => {
  const file = await textFile('hdr.txt', '# time x y polarity\n1 1 2 1\n2 3 4 0\n');
  assert.equal((await parseTxt(file)).length, 2);
});

test('txt: only comments is rejected', async () => {
  const file = await textFile('comments.txt', '# nothing here\n% still nothing\n');
  await assert.rejects(parseTxt(file), /empty or contains only comments/);
});

// ---------------------------------------------------------------- NPY

const flat = new Float64Array(ROWS.flat());

test('npy: N x 4 array', async () => {
  const file = path.join(dir, 'nx4.npy');
  await fs.writeFile(file, npyBytes('<f8', [5, 4], flat));
  const events = await parseNpy(file);

  assert.equal(events.length, 5);
  assert.deepEqual(events[2], { t: 3, x: 5, y: 6, p: 1 });
});

test('npy: 4 x N array', async () => {
  const transposed = new Float64Array(20);
  ROWS.forEach((row, i) => row.forEach((v, c) => (transposed[c * 5 + i] = v)));

  const file = path.join(dir, '4xn.npy');
  await fs.writeFile(file, npyBytes('<f8', [4, 5], transposed));

  assert.deepEqual((await parseNpy(file))[2], { t: 3, x: 5, y: 6, p: 1 });
});

test('npy: Fortran order', async () => {
  const columnMajor = new Float64Array(20);
  ROWS.forEach((row, i) => row.forEach((v, c) => (columnMajor[c * 5 + i] = v)));

  const file = path.join(dir, 'fortran.npy');
  await fs.writeFile(file, npyBytes('<f8', [5, 4], columnMajor, true));

  assert.deepEqual((await parseNpy(file))[2], { t: 3, x: 5, y: 6, p: 1 });
});

test('npy: flat int32 array', async () => {
  const file = path.join(dir, 'flat.npy');
  await fs.writeFile(file, npyBytes('<i4', [20], new Int32Array(ROWS.flat())));

  assert.equal((await parseNpy(file)).length, 5);
});

test('npy: a NaN row is skipped and counted', async () => {
  const withNaN = new Float64Array(flat);
  withNaN[9] = NaN; // row 2, column x

  const file = path.join(dir, 'nan.npy');
  await fs.writeFile(file, npyBytes('<f8', [5, 4], withNaN));
  const events = await parseNpy(file);

  assert.equal(events.length, 4);
  assert.equal(events.skippedRows, 1);
});

test('npy: unsupported data type is rejected', async () => {
  const file = path.join(dir, 'f2.npy');
  await fs.writeFile(file, npyBytes('<f2', [5, 4], new Uint16Array(20)));

  await assert.rejects(parseNpy(file), /Unsupported NPY data type/);
});

test('npy: cut-off file is reported as truncated', async () => {
  const bytes = npyBytes('<f8', [5, 4], flat);

  const file = path.join(dir, 'trunc.npy');
  await fs.writeFile(file, bytes.subarray(0, bytes.length - 40));

  await assert.rejects(parseNpy(file), /truncated/);
});

test('npy: not an NPY file', async () => {
  const file = await textFile('fake.npy', 'this is not a numpy file at all');
  await assert.rejects(parseNpy(file), /Invalid NPY file header/);
});

// ---------------------------------------------------------------- HDF5

test('h5: round trip through the writer', async () => {
  const columns = {
    n: 4,
    t: new Float64Array([1, 2, 3, 4]),
    x: new Uint16Array([1, 2, 3, 4]),
    y: new Uint16Array([5, 6, 7, 8]),
    p: new Int8Array([1, 0, 1, 1])
  };
  const file = path.join(dir, 'roundtrip.h5');
  await writeHdf5(columns, file, { width: 10, height: 10, format: 'test' });

  const events = await parseH5(file);

  assert.equal(events.length, 4);
  assert.deepEqual(events[3], { t: 4, x: 4, y: 8, p: 1 });
});

test('h5: a text file is rejected', async () => {
  const file = await textFile('fake.h5', 'not hdf5');
  await assert.rejects(parseH5(file), /Cannot open HDF5 file|Not an EVAA HDF5 file/);
});

// ---------------------------------------------------------------- validation

test('validation: NaN and Infinity are rejected', () => {
  for (const bad of [NaN, Infinity]) {
    assert.throws(() => validateEvents([{ t: bad, x: 1, y: 1, p: 1 }]));
    assert.throws(() => validateEvents([{ t: 1, x: bad, y: 1, p: 1 }]));
  }
});

test('validation: polarity 2 and negative positions are rejected', () => {
  assert.throws(() => validateEvents([{ t: 1, x: 1, y: 1, p: 2 }]), /polarity/);
  assert.throws(() => validateEvents([{ t: 1, x: -1, y: 1, p: 1 }]), /negative/);
});

// ---------------------------------------------------------------- ingest + visualize

test('ingest: csv to HDF5 and Parquet, then visualize', async () => {
  const file = await textFile(
    'ingest.csv',
    't,x,y,p\n3,5,6,1\n1,1,2,1\n2,3,4,0\n4,7,8,0\n'
  );
  const out = path.join(dir, 'out-ingest');
  const result = await ingest(file, out, { log: false });

  assert.equal(result.success, true);
  assert.equal(result.eventCount, 4);
  assert.equal(result.metadata.sortedInput, false); // input was out of order
  assert.deepEqual(result.preview.map((r) => r.t), [1, 2, 3, 4]); // now sorted
  assert.equal(result.benchmark.outputCorrectness.passed, true);

  for (const f of result.files) {
    assert.ok((await fs.stat(f.path)).size > 0, `${f.kind} file is not empty`);
  }

  const parquet = result.files.find((f) => f.kind === 'PARQUET').path;
  const viz = await visualize(parquet);

  assert.equal(viz.metadata.eventCount, 4);
  assert.equal(viz.polarity.on + viz.polarity.off, 4);
  assert.equal(viz.quality.completeness, 1);
});

test('ingest: skipped rows are reported in the metadata', async () => {
  const file = await textFile('skip.csv', 't,x,y,p\n1,1,2,1\nbad,1,2,1\n2,3,4,0\n');
  const result = await ingest(file, path.join(dir, 'out-skip'), { log: false });

  assert.equal(result.eventCount, 2);
  assert.equal(result.metadata.skippedRows, 1);
});

test('ingest: polarity 2 is rejected', async () => {
  const file = await textFile('pol2.csv', 't,x,y,p\n1,1,2,2\n');
  await assert.rejects(
    ingest(file, path.join(dir, 'out-pol'), { log: false }),
    /Invalid polarity/
  );
});

test('ingest: unsupported extension is rejected', async () => {
  const file = await textFile('data.xyz', '1,2,3,4');
  await assert.rejects(
    ingest(file, path.join(dir, 'out-xyz'), { log: false }),
    /Unsupported file format/
  );
});

// ---------------------------------------------------------------- real MAT file (optional)

const matSample = path.join(here, '..', 'test', 'Myfile.mat');

test(
  'mat: sample recording has 4,257,681 events at 240 x 180',
  { skip: !existsSync(matSample) && 'test/Myfile.mat not found' },
  async () => {
    const out = path.join(dir, 'out-mat');
    const result = await ingest(matSample, out, { log: false });

    assert.equal(result.eventCount, 4257681);
    assert.equal(result.metadata.width, 240);
    assert.equal(result.metadata.height, 180);
  }
);