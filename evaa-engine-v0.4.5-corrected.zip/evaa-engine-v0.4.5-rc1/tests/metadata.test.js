import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

import { ingest } from '../index.js';
import {
  extractEventMetadata,
  createEventAccumulator,
  generateMetadata,
  timestampToSeconds,
  buildPerformanceMetadata
} from '../utils/evaa-metadata/index.js';

/*
 * Tests for the metadata report (Aditi's evaa-metadata, made memory-safe).
 * The first five tests are the original package tests; the rest check the
 * accumulator, the column path and the integration with ingest().
 */

let dir;

before(async () => {
  dir = await fs.mkdtemp(path.join(os.tmpdir(), 'evaa-meta-'));
});

after(async () => {
  await fs.rm(dir, { recursive: true, force: true });
});

// ---------------------------------------------------- original package tests

test('does not assume timestamps are microseconds', () => {
  const result = extractEventMetadata([
    { t: 1, x: 0, y: 0, p: 1 },
    { t: 3, x: 1, y: 1, p: -1 }
  ]);

  assert.equal(result.timestamps.unit, 'unknown');
  assert.equal(result.timestamps.durationUs, null);
  assert.equal(result.analytics.eventRatePerSecond, null);
});

test('calculates rate with a verified timestamp unit', () => {
  const result = extractEventMetadata(
    [
      { t: 1000, x: 0, y: 0, p: 1 },
      { t: 2000, x: 1, y: 0, p: -1 }
    ],
    {
      timestampUnit: 'microseconds',
      width: 2,
      height: 1,
      resolutionSource: 'provided_verified',
      resolutionVerified: true
    }
  );

  assert.equal(result.timestamps.durationUs, 1000);
  assert.equal(result.analytics.eventRatePerSecond, 2000);
  assert.equal(result.sensor.activePixelCount, 2);
  assert.equal(result.sensor.activePixelSparsityPercent, 0);
  assert.equal(result.sensor.spatialCoveragePercent, 100);
  assert.equal(result.sensor.resolutionVerified, true);
});

test('flags out-of-order events and estimated dimensions', () => {
  const result = extractEventMetadata(
    [
      { t: 9, x: 2, y: 3, p: 0 },
      { t: 4, x: 0, y: 1, p: 1 }
    ],
    { timestampUnit: 'milliseconds' }
  );

  assert.equal(result.timestamps.sortedInput, false);
  assert.equal(result.sensor.width, 3);
  assert.equal(result.sensor.height, 4);
  assert.equal(result.sensor.resolutionVerified, false);
  assert.ok(result.dataQuality.warnings.length >= 2);
});

test('reports missing RTF and bandwidth measurements honestly', () => {
  const result = buildPerformanceMetadata();

  assert.equal(result.realTimeFactor, null);
  assert.equal(result.peakBandwidthBytesPerSecond, null);
});

test('calculates RTF and transfer rate from measurements', () => {
  const result = buildPerformanceMetadata({
    timings: { totalIngestionMs: 500 },
    recordingDurationSeconds: 2,
    transfer: { bytesTransferred: 1000, durationSeconds: 2 }
  });

  assert.equal(result.realTimeFactor, 4);
  assert.equal(result.peakBandwidthBytesPerSecond, 500);
});

test('converts only recognized timestamp units', () => {
  assert.equal(timestampToSeconds(1000, 'milliseconds'), 1);
  assert.equal(timestampToSeconds(1000000, 'microseconds'), 1);
  assert.equal(timestampToSeconds(1000, 'unknown'), null);
});

// ----------------------------------------------------- accumulator behaviour

const sampleEvents = [
  { t: 1000, x: 0, y: 0, p: 1 },
  { t: 1500, x: 2, y: 1, p: -1 },
  { t: 2500, x: 2, y: 1, p: 1 },
  { t: 2500, x: 5, y: 4, p: 0 }
];

function toColumns(events) {
  const n = events.length;
  const cols = {
    n,
    t: new Float64Array(n),
    x: new Uint16Array(n),
    y: new Uint16Array(n),
    p: new Int8Array(n)
  };

  events.forEach((e, i) => {
    cols.t[i] = e.t;
    cols.x[i] = e.x;
    cols.y[i] = e.y;
    cols.p[i] = e.p;
  });

  return cols;
}

test('report values are correct for a small sorted input', () => {
  const r = extractEventMetadata(sampleEvents, {
    timestampUnit: 'microseconds'
  });

  assert.equal(r.eventCount, 4);
  assert.equal(r.validEventCount, 4);
  assert.equal(r.timestamps.minTimestamp, 1000);
  assert.equal(r.timestamps.maxTimestamp, 2500);
  assert.equal(r.timestamps.duration, 1500);
  assert.equal(r.timestamps.sortedInput, true);
  assert.deepEqual(r.polarity.values, [-1, 0, 1]);
  assert.equal(r.polarity.positiveEventCount, 2);
  assert.equal(r.polarity.negativeEventCount, 1);
  assert.equal(r.polarity.zeroPolarityCount, 1);
  assert.equal(r.sensor.width, 6);
  assert.equal(r.sensor.height, 5);
  assert.equal(r.sensor.activePixelCount, 3); // (0,0) (2,1) (5,4)
  assert.deepEqual(r.analytics.eventDistribution.timestampGap, {
    mean: 500,
    min: 0,
    max: 1000
  });
});

test('column path gives the same report as the array path', () => {
  const options = {
    timestampUnit: 'microseconds',
    width: 640,
    height: 480
  };

  const fromArray = extractEventMetadata(sampleEvents, options);

  const acc = createEventAccumulator(options);
  acc.addColumns(toColumns(sampleEvents));
  const fromColumns = acc.finish();

  assert.deepEqual(fromColumns, fromArray);
});

test('feeding events in batches gives the same report as one block', () => {
  const events = [];

  for (let i = 0; i < 5000; i++) {
    events.push({ t: i * 7, x: i % 100, y: (i * 3) % 60, p: i % 2 });
  }

  const options = { timestampUnit: 'microseconds' };
  const whole = extractEventMetadata(events, options);

  const cols = toColumns(events);
  const acc = createEventAccumulator(options);

  for (let start = 0; start < cols.n; start += 777) {
    acc.addColumns(cols, start, Math.min(cols.n, start + 777));
  }

  assert.deepEqual(acc.finish(), whole);
});

test('out-of-order arrays still get exact timestamp gap statistics', () => {
  const unsorted = [
    { t: 30, x: 1, y: 1, p: 1 },
    { t: 10, x: 2, y: 2, p: 1 },
    { t: 20, x: 3, y: 3, p: 1 }
  ];

  const r = extractEventMetadata(unsorted, {
    timestampUnit: 'microseconds'
  });

  assert.equal(r.timestamps.sortedInput, false);
  assert.deepEqual(r.analytics.eventDistribution.timestampGap, {
    mean: 10,
    min: 10,
    max: 10
  });
});

test('inputSorted tells the report about the order before sorting', () => {
  const acc = createEventAccumulator({
    timestampUnit: 'microseconds',
    inputSorted: false
  });

  acc.addColumns(toColumns(sampleEvents)); // already sorted columns
  const r = acc.finish();

  assert.equal(r.timestamps.sortedInput, false);
  assert.equal(r.timestamps.outOfOrderDetected, true);
  assert.ok(r.analytics.eventDistribution.timestampGap !== null);
});

test('invalid events are counted and excluded', () => {
  const r = extractEventMetadata(
    [
      { t: 1, x: 0, y: 0, p: 1 },
      { t: NaN, x: 0, y: 0, p: 1 },
      { t: 2, x: -1, y: 0, p: 1 },
      { t: 3, x: 1, y: 1, p: 7 },
      null
    ],
    { timestampUnit: 'microseconds' }
  );

  assert.equal(r.eventCount, 5);
  assert.equal(r.validEventCount, 1);
  assert.equal(r.invalidEventCount, 4);
  assert.equal(r.dataQuality.status, 'invalid_events_detected');
});

test('an empty input gives an empty but valid report', () => {
  const r = extractEventMetadata([], { timestampUnit: 'microseconds' });

  assert.equal(r.eventCount, 0);
  assert.equal(r.timestamps.duration, null);
  assert.equal(r.sensor.width, null);
  assert.equal(r.analytics.eventRatePerSecond, null);
});

test('memory stays flat: 8 million events do not grow the heap', () => {
  const n = 8_000_000;
  const cols = {
    n,
    t: new Float64Array(n),
    x: new Uint16Array(n),
    y: new Uint16Array(n),
    p: new Int8Array(n)
  };

  for (let i = 0; i < n; i++) {
    cols.t[i] = i * 3;
    cols.x[i] = i % 640;
    cols.y[i] = (i >> 3) % 480;
    cols.p[i] = i & 1;
  }

  if (global.gc) global.gc();
  const before = process.memoryUsage().heapUsed;

  const acc = createEventAccumulator({
    timestampUnit: 'microseconds',
    width: 640,
    height: 480
  });
  acc.addColumns(cols);
  const r = acc.finish();

  const growthMB = (process.memoryUsage().heapUsed - before) / 1048576;

  assert.equal(r.validEventCount, n);
  assert.ok(growthMB < 50, `heap grew by ${growthMB.toFixed(1)} MB`);
});

// ------------------------------------------------------------- generateMetadata

test('generateMetadata accepts columns and builds the full report', async () => {
  const r = await generateMetadata({
    originalFileName: 'sample.csv',
    fileSizeBytes: 128,
    columns: toColumns(sampleEvents),
    options: { timestampUnit: 'microseconds', width: 640, height: 480 },
    timings: { totalIngestionMs: 12.4 },
    outputFiles: {
      hdf5: { path: 'a.h5', sizeBytes: 2048 },
      parquet: { path: 'a.parquet', sizeBytes: 1024 },
      validationStatus: 'passed'
    }
  });

  assert.equal(r.schemaVersion, '1.0.0');
  assert.equal(r.file.format, 'CSV');
  assert.equal(r.file.fileSizeBytes, 128);
  assert.equal(r.validEventCount, 4);
  assert.equal(r.performance.hdf5OutputSizeBytes, 2048);
  assert.equal(r.outputFiles.parquet, 'a.parquet');
  assert.equal(r.validation.status, 'passed');
});

// ------------------------------------------------------------ ingest() wiring

async function csv(name, rows) {
  const file = path.join(dir, name);
  await fs.writeFile(file, 't,x,y,p\n' + rows.join('\n') + '\n');
  return file;
}

test('ingest() returns the report and leaves the old metadata unchanged', async () => {
  const file = await csv('a.csv', [
    '1000,1,2,1',
    '2000,3,4,0',
    '3000,5,6,1'
  ]);

  const result = await ingest(file, path.join(dir, 'out-a'), {
    log: false,
    originalFileName: 'my recording.csv'
  });

  // the old metadata block is exactly what the backend already reads
  assert.equal(result.metadata.format, 'csv');
  assert.equal(result.metadata.eventCount, 3);
  assert.equal(result.metadata.width, 6);
  assert.equal(result.metadata.height, 7);
  assert.equal(result.metadata.durationUs, 2000);
  assert.equal(result.metadata.timestampUnit, 'microseconds');
  assert.deepEqual(result.metadata.eventModel, ['t', 'x', 'y', 'p']);

  // the new report
  const r = result.report;
  assert.ok(r, 'report is present');
  assert.equal(r.file.fileName, 'my recording.csv');
  assert.equal(r.file.format, 'CSV');
  assert.equal(r.validEventCount, 3);
  assert.equal(r.timestamps.unit, 'microseconds');
  assert.equal(r.timestamps.durationUs, 2000);
  assert.equal(r.sensor.activePixelCount, 3);
  assert.equal(r.outputFiles.hdf5, path.join(dir, 'out-a', 'events.h5'));
  assert.equal(r.validation.outputCorrectness, true);
  assert.ok(r.file.fileSizeBytes > 0);
  assert.ok(r.performance.hdf5OutputSizeBytes > 0);
  assert.ok(r.performance.parquetOutputSizeBytes > 0);
  assert.ok(r.performance.peakMemoryMB > 0);
});

test('ingest() reports unsorted input as unsorted, though the files are sorted', async () => {
  const file = await csv('b.csv', [
    '3000,1,1,1',
    '1000,2,2,0',
    '2000,3,3,1'
  ]);

  const result = await ingest(file, path.join(dir, 'out-b'), {
    log: false
  });

  assert.equal(result.metadata.sortedInput, false);
  assert.equal(result.report.timestamps.sortedInput, false);
  assert.deepEqual(
    result.report.analytics.eventDistribution.timestampGap,
    { mean: 1000, min: 1000, max: 1000 }
  );
});

test('ingest() passes supplied sensor size to the report', async () => {
  const file = await csv('c.csv', ['1,1,1,1', '2,2,2,0']);

  const result = await ingest(file, path.join(dir, 'out-c'), {
    log: false,
    width: 640,
    height: 480
  });

  assert.equal(result.report.sensor.width, 640);
  assert.equal(result.report.sensor.height, 480);
  assert.equal(result.report.sensor.resolutionSource, 'provided');
  assert.equal(result.report.sensor.sensorPixelCount, 640 * 480);
});

test('options.metadataReport = false switches the report off', async () => {
  const file = await csv('d.csv', ['1,1,1,1', '2,2,2,0']);

  const result = await ingest(file, path.join(dir, 'out-d'), {
    log: false,
    metadataReport: false
  });

  assert.equal(result.report, null);
  assert.equal(result.eventCount, 2);
  assert.equal(result.success, true);
});