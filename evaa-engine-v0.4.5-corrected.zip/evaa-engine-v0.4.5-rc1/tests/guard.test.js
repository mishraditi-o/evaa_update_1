import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

import { ingest } from '../index.js';
import { DEFAULT_MAX_INPUT_BYTES } from '../ingest/index.js';

/*
 * Tests for the input size guard in ingest().
 * Test files are created on the fly in a temporary folder.
 */

let dir;
let file;

before(async () => {
  dir = await fs.mkdtemp(path.join(os.tmpdir(), 'evaa-guard-'));
  file = path.join(dir, 'small.csv');
  await fs.writeFile(file, 't,x,y,p\n1,1,2,1\n2,3,4,0\n');
});

after(async () => {
  await fs.rm(dir, { recursive: true, force: true });
});

test('guard: a file above maxInputBytes is rejected with a clear message', async () => {
  await assert.rejects(
    ingest(file, path.join(dir, 'out-big'), { log: false, maxInputBytes: 10 }),
    /Input file is too large for this engine version/
  );
});

test('guard: nothing is written when the file is rejected', async () => {
  const out = path.join(dir, 'out-nothing');

  await assert.rejects(ingest(file, out, { log: false, maxInputBytes: 10 }));
  await assert.rejects(fs.stat(out)); // output folder was never created
});

test('guard: a file under the limit still works', async () => {
  const result = await ingest(file, path.join(dir, 'out-ok'), { log: false });

  assert.equal(result.eventCount, 2);
});

test('guard: Infinity switches the guard off', async () => {
  const result = await ingest(file, path.join(dir, 'out-inf'), {
    log: false,
    maxInputBytes: Infinity
  });

  assert.equal(result.eventCount, 2);
});

test('guard: the default limit is 250 MB', () => {
  assert.equal(DEFAULT_MAX_INPUT_BYTES, 250 * 1024 * 1024);
});

test('guard: a missing file still gives the parser error, not a size error', async () => {
  await assert.rejects(
    ingest(path.join(dir, 'does-not-exist.csv'), path.join(dir, 'out-missing'), {
      log: false
    }),
    (error) => !/too large/.test(error.message)
  );
});