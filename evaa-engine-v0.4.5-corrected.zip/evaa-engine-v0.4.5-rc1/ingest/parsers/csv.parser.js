import { createReadStream } from "node:fs";
import readline from "node:readline";

/*
 * CSV parser -> EVAA events { t, x, y, p }
 *
 * - Reads the file line by line (no whole-file string in memory).
 * - Header optional. If present it must name t, x, y, p (aliases below).
 * - Delimiter is detected from the first line: comma, semicolon or tab.
 * - A UTF-8 byte order mark (added by Excel) is ignored.
 * - Empty cells and unreadable rows are skipped and counted in
 *   events.skippedRows, never dropped silently.
 */

// Accepted header names for each event field.
// Anything else is rejected, so other tables are never read as events.
const COLUMN_ALIASES = {
  t: ["t", "time", "timestamp", "ts", "timestamp_us", "t_us"],
  x: ["x", "pos_x", "coord_x"],
  y: ["y", "pos_y", "coord_y"],
  p: ["p", "pol", "polarity"],
};

const FIELDS = ["t", "x", "y", "p"];
const DELIMITERS = [",", ";", "\t"];

const clean = (value) => value.trim().replace(/^["']|["']$/g, "");

// A header token is text that is not a number (nan / inf count as numbers)
const isHeaderToken = (token) =>
  token !== "" &&
  Number.isNaN(Number(token)) &&
  !/^[+-]?(nan|inf|infinity)$/i.test(token);

// Empty cell -> NaN (Number('') would be 0)
function toNumber(raw) {
  const token = clean(raw ?? "");
  return token === "" ? NaN : Number(token);
}

function detectDelimiter(line) {
  let best = ",";
  let bestCount = 0;

  for (const delimiter of DELIMITERS) {
    const count = line.split(delimiter).length - 1;

    if (count > bestCount) {
      best = delimiter;
      bestCount = count;
    }
  }

  return best;
}

function resolveHeader(firstRow) {
  const names = firstRow.map((name) => name.toLowerCase());
  const idx = {};

  for (const field of FIELDS) {
    idx[field] = names.findIndex((name) =>
      COLUMN_ALIASES[field].includes(name),
    );
  }

  const missing = FIELDS.filter((field) => idx[field] === -1);

  if (missing.length > 0) {
    throw new Error(
      `CSV header must name the columns t, x, y, p. Missing: ${missing.join(", ")}. Found: ${firstRow.join(", ")}`,
    );
  }

  return idx;
}

export async function parseCsv(filePath) {
  if (!filePath) {
    throw new Error("CSV file path is required");
  }

  const input = createReadStream(filePath, { encoding: "utf8" });
  const lines = readline.createInterface({
    input,
    crlfDelay: Infinity,
  });

  const events = [];
  let skippedRows = 0;
  let lineNumber = 0;
  let delimiter = ",";
  let idx = null;

  try {
    for await (const raw of lines) {
      // Ignore a byte order mark on the very first line
      const line = lineNumber++ === 0 ? raw.replace(/^﻿/, "") : raw;
      const trimmed = line.trim();

      // Ignore empty lines and comments
      if (trimmed.length === 0 || trimmed.startsWith("#")) {
        continue;
      }

      // First useful line: header or data? Decide the column layout.
      if (idx === null) {
        delimiter = detectDelimiter(trimmed);
        const firstRow = trimmed.split(delimiter).map(clean);

        if (firstRow.some(isHeaderToken)) {
          idx = resolveHeader(firstRow);
          continue;
        }

        if (firstRow.length !== 4) {
          throw new Error(
            `No header found. Expected 4 columns (t, x, y, p), found ${firstRow.length}`,
          );
        }

        idx = { t: 0, x: 1, y: 2, p: 3 };
        // fall through: this first line is data
      }

      const tokens = trimmed.split(delimiter);

      if (tokens.length < 4) {
        skippedRows++;
        continue;
      }

      const t = toNumber(tokens[idx.t]);
      const x = toNumber(tokens[idx.x]);
      const y = toNumber(tokens[idx.y]);
      const p = toNumber(tokens[idx.p]);

      if (
        Number.isFinite(t) &&
        Number.isFinite(x) &&
        Number.isFinite(y) &&
        Number.isFinite(p)
      ) {
        events.push({
          t,
          x: Math.floor(x),
          y: Math.floor(y),
          p: Math.floor(p),
        });
      } else {
        skippedRows++;
      }
    }
  } finally {
    lines.close();
    input.destroy();
  }

  if (idx === null) {
    throw new Error("CSV file is empty or contains no valid lines");
  }

  // Rows that could not be read are counted, never dropped silently.
  // ingest() reports this number in metadata.skippedRows.
  events.skippedRows = skippedRows;

  return events;
}
