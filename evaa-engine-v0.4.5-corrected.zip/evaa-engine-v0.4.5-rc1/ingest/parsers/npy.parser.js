import fs from 'node:fs/promises';

/*
 * NPY parser -> EVAA events { t, x, y, p }
 *
 * Supports NumPy .npy versions 1, 2 and 3:
 *  - structured arrays with fields t, x, y, p (or exactly 4 fields in
 *    that order)
 *  - N x 4 or 4 x N numeric arrays (C order or Fortran order)
 *  - flat numeric arrays [t, x, y, p, t, x, y, p, ...]
 *
 * Numeric types: float32/64, int8..64, uint8..64, bool.
 * Rows with a non-finite value are skipped and counted in
 * events.skippedRows, never dropped silently.
 */

const SUPPORTED_KINDS = ['f', 'i', 'u', 'b'];

function getTypeInfo(typeStr) {
  const littleEndian = !typeStr.startsWith('>');

  const code = typeStr.replace(/^[<>=|]/, '');
  const kind = code[0];
  const size = parseInt(code.slice(1), 10) || 1;

  const supported =
    (kind === 'f' && (size === 4 || size === 8)) ||
    ((kind === 'i' || kind === 'u') && [1, 2, 4, 8].includes(size)) ||
    (kind === 'b' && size === 1);

  if (!supported) {
    throw new Error(
      `Unsupported NPY data type "${typeStr}". Use float32/64, int8..64, uint8..64 or bool.`
    );
  }

  return {
    kind,
    size,
    littleEndian
  };
}

function readValue(view, offset, typeInfo) {
  const { kind, size, littleEndian } = typeInfo;

  switch (kind) {
    case 'f':
      return size === 8
        ? view.getFloat64(offset, littleEndian)
        : view.getFloat32(offset, littleEndian);

    case 'i':
      if (size === 8) return Number(view.getBigInt64(offset, littleEndian));
      if (size === 4) return view.getInt32(offset, littleEndian);
      if (size === 2) return view.getInt16(offset, littleEndian);
      return view.getInt8(offset);

    case 'u':
      if (size === 8) return Number(view.getBigUint64(offset, littleEndian));
      if (size === 4) return view.getUint32(offset, littleEndian);
      if (size === 2) return view.getUint16(offset, littleEndian);
      return view.getUint8(offset);

    default: // 'b'
      return view.getUint8(offset) ? 1 : 0;
  }
}

function findColumn(fields, keywords) {
  for (const keyword of keywords) {
    const found = fields.find((field) => field.name === keyword);

    if (found) {
      return found;
    }
  }

  return null;
}

export async function parseNpy(filePath) {
  if (!filePath) {
    throw new Error('NPY file path is required');
  }

  const buffer = await fs.readFile(filePath);

  if (buffer.length < 10) {
    throw new Error('Invalid NPY file: file is too small');
  }

  const u8 = new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);

  // NPY magic header
  const magic = [0x93, 0x4e, 0x55, 0x4d, 0x50, 0x59];

  for (let i = 0; i < magic.length; i++) {
    if (u8[i] !== magic[i]) {
      throw new Error('Invalid NPY file header. File must start with \\x93NUMPY.');
    }
  }

  const major = u8[6];

  let headerLength;
  let dataOffset;

  if (major === 1) {
    headerLength = u8[8] | (u8[9] << 8);
    dataOffset = 10 + headerLength;
  } else if (major === 2 || major === 3) {
    if (buffer.length < 12) {
      throw new Error('Invalid NPY file: file is too small');
    }

    headerLength =
      (u8[8] | (u8[9] << 8) | (u8[10] << 16) | (u8[11] << 24)) >>> 0;
    dataOffset = 12 + headerLength;
  } else {
    throw new Error(`Unsupported NPY version: ${major}`);
  }

  if (dataOffset > buffer.length) {
    throw new Error('Invalid NPY file: header is longer than the file');
  }

  const headerStart = dataOffset - headerLength;

  const headerText = new TextDecoder('latin1').decode(
    u8.subarray(headerStart, dataOffset)
  );

  // Parse shape
  const shapeMatch = headerText.match(/['"]shape['"]\s*:\s*\(([^)]*)\)/);

  if (!shapeMatch) {
    throw new Error('Could not parse shape from NPY header.');
  }

  const shape = shapeMatch[1]
    .split(',')
    .map((value) => parseInt(value.trim(), 10))
    .filter(Number.isFinite);

  // Parse dtype
  const descrMatch = headerText.match(
    /['"]descr['"]\s*:\s*(\[[^\]]+\]|'[^']+'|"[^"]+")/
  );

  if (!descrMatch) {
    throw new Error('Could not parse descr from NPY header.');
  }

  const descrRaw = descrMatch[1].trim();

  const fortranMatch = headerText.match(
    /['"]fortran_order['"]\s*:\s*(True|False)/
  );

  const fortranOrder = fortranMatch ? fortranMatch[1] === 'True' : false;

  // A view over the data part of the file. No copy of the data is made.
  const view = new DataView(
    buffer.buffer,
    buffer.byteOffset + dataOffset,
    buffer.byteLength - dataOffset
  );

  const rows = [];
  let skippedRows = 0;

  // Adds one event, or counts it as skipped when a value is not finite
  const add = (t, x, y, p) => {
    if (
      Number.isFinite(t) &&
      Number.isFinite(x) &&
      Number.isFinite(y) &&
      Number.isFinite(p)
    ) {
      rows.push({
        t,
        x: Math.floor(x),
        y: Math.floor(y),
        p: Math.floor(p)
      });
    } else {
      skippedRows++;
    }
  };

  /*
   * Structured NPY array
   *
   * Example:
   * [
   *   ('timestamp', '<f8'),
   *   ('x', '<i4'),
   *   ('y', '<i4'),
   *   ('polarity', '<i1')
   * ]
   */
  if (descrRaw.startsWith('[')) {
    const fieldMatches = [
      ...descrRaw.matchAll(/\(\s*['"]([^'"]+)['"]\s*,\s*['"]([^'"]+)['"]\s*\)/g)
    ];

    if (fieldMatches.length === 0) {
      throw new Error('Failed to parse structured NPY fields.');
    }

    let totalRecordSize = 0;

    const fields = fieldMatches.map((match) => {
      const name = match[1].toLowerCase();
      const typeInfo = getTypeInfo(match[2]);
      const offset = totalRecordSize;

      totalRecordSize += typeInfo.size;

      return { name, typeInfo, offset };
    });

    const numRecords =
      shape[0] || Math.floor(view.byteLength / totalRecordSize);

    const stride =
      numRecords > 0 && view.byteLength >= numRecords * totalRecordSize
        ? Math.floor(view.byteLength / numRecords)
        : totalRecordSize;

    const colMap = {
      t: findColumn(fields, ['t', 'ts', 'time', 'timestamp', 'timestamp_us', 't_us']),
      x: findColumn(fields, ['x', 'pos_x', 'coord_x']),
      y: findColumn(fields, ['y', 'pos_y', 'coord_y']),
      p: findColumn(fields, ['p', 'pol', 'polarity'])
    };

    // If names are not recognised, accept exactly 4 fields in the
    // order t, x, y, p. Any other layout is rejected.
    if (!colMap.t || !colMap.x || !colMap.y || !colMap.p) {
      if (fields.length === 4) {
        colMap.t = fields[0];
        colMap.x = fields[1];
        colMap.y = fields[2];
        colMap.p = fields[3];
      } else {
        throw new Error(
          `Structured NPY must have fields t, x, y, p (or exactly 4 fields in that order). Found: ${fields
            .map((field) => field.name)
            .join(', ')}`
        );
      }
    }

    for (let i = 0; i < numRecords; i++) {
      const recordOffset = i * stride;

      if (recordOffset + totalRecordSize > view.byteLength) {
        break;
      }

      add(
        readValue(view, recordOffset + colMap.t.offset, colMap.t.typeInfo),
        readValue(view, recordOffset + colMap.x.offset, colMap.x.typeInfo),
        readValue(view, recordOffset + colMap.y.offset, colMap.y.typeInfo),
        readValue(view, recordOffset + colMap.p.offset, colMap.p.typeInfo)
      );
    }
  } else {
    /*
     * Regular numeric NPY array
     */
    const typeInfo = getTypeInfo(descrRaw.replace(/['"]/g, ''));
    const elementSize = typeInfo.size;

    const totalElements = Math.floor(view.byteLength / elementSize);

    // The header says how many values to expect. Fewer in the file means
    // the file is cut short.
    const expected = shape.reduce((a, b) => a * b, 1);

    if (shape.length > 0 && expected * elementSize > view.byteLength) {
      throw new Error(
        `NPY file is truncated: the header declares ${expected} values but the file holds ${totalElements}.`
      );
    }

    // N x 4 or 4 x N
    if (shape.length === 2) {
      const rowsCount = shape[0];
      const colsCount = shape[1];

      // Position of element (row, col) in the file
      const at = (row, col) =>
        fortranOrder ? col * rowsCount + row : row * colsCount + col;

      const val = (row, col) =>
        readValue(view, at(row, col) * elementSize, typeInfo);

      if (colsCount === 4) {
        for (let i = 0; i < rowsCount; i++) {
          add(val(i, 0), val(i, 1), val(i, 2), val(i, 3));
        }
      } else if (rowsCount === 4) {
        for (let i = 0; i < colsCount; i++) {
          add(val(0, i), val(1, i), val(2, i), val(3, i));
        }
      } else {
        throw new Error(
          `NPY array has shape (${rowsCount}, ${colsCount}). Expected N x 4 with columns t, x, y, p.`
        );
      }

      // Flat array: [t,x,y,p,t,x,y,p,...]
    } else if (shape.length === 1) {
      if (totalElements % 4 !== 0) {
        throw new Error(
          `NPY array has ${totalElements} values, which is not a multiple of 4 (t, x, y, p).`
        );
      }

      const count = Math.floor(totalElements / 4);

      for (let i = 0; i < count; i++) {
        const index = i * 4;

        add(
          readValue(view, index * elementSize, typeInfo),
          readValue(view, (index + 1) * elementSize, typeInfo),
          readValue(view, (index + 2) * elementSize, typeInfo),
          readValue(view, (index + 3) * elementSize, typeInfo)
        );
      }
    }
  }

  if (rows.length === 0) {
    throw new Error(
      `Could not map NPY array to (t, x, y, p). Shape: (${shape.join(
        ', '
      )}), dtype: ${descrRaw}`
    );
  }

  // Rows that could not be read are counted, never dropped silently.
  rows.skippedRows = skippedRows;

  return rows;
}