import { createReadStream } from 'node:fs';
import readline from 'node:readline';

/*
 * TXT parser -> EVAA events { t, x, y, p }
 *
 * - Columns separated by spaces, tabs or commas.
 * - Header optional, either a plain first line or a comment line
 *   such as "# t x y p" or "% timestamp x y polarity".
 * - Reads line by line (no whole-file string in memory).
 * - Unreadable rows are skipped and counted in events.skippedRows,
 *   never dropped silently.
 */

const REQUIRED = ['t', 'x', 'y', 'p'];

const COLUMN_ALIASES = {
  t: ['t', 'time', 'timestamp', 'ts', 'timestamp_s', 'timestamp_us', 't_us'],
  x: ['x', 'pos_x', 'coord_x'],
  y: ['y', 'pos_y', 'coord_y'],
  p: ['p', 'pol', 'polarity']
};

function splitTokens(line) {
  return line.trim().split(/[\s,]+/);
}

// A header token is text that is not a number. Numbers such as 1e-3 or
// 2.5E6 are numbers, not header text (nan / inf count as numbers too).
function isHeaderToken(token) {
  return (
    token !== '' &&
    Number.isNaN(Number(token)) &&
    !/^[+-]?(nan|inf|infinity)$/i.test(token)
  );
}

function looksLikeHeader(tokens) {
  return tokens.some(isHeaderToken);
}

function matchesAnyAlias(tokens) {
  return tokens.some((token) =>
    REQUIRED.some((key) => COLUMN_ALIASES[key].includes(token.toLowerCase()))
  );
}

function resolveHeader(headerTokens) {
  const names = headerTokens.map((name) => name.toLowerCase());
  const idx = {};

  for (const key of REQUIRED) {
    idx[key] = names.findIndex((name) => COLUMN_ALIASES[key].includes(name));
  }

  const missing = REQUIRED.filter((key) => idx[key] === -1);

  if (missing.length > 0) {
    throw new Error(`Missing required columns: ${missing.join(', ')}`);
  }

  return idx;
}

export async function parseTxt(filePath) {
  if (!filePath) {
    throw new Error('TXT file path is required');
  }

  const input = createReadStream(filePath, { encoding: 'utf8' });
  const lines = readline.createInterface({
    input,
    crlfDelay: Infinity
  });

  const events = [];
  let skippedRows = 0;
  let lineNumber = 0;
  let headerTokens = null;
  let idx = null;
  let needed = 4;

  try {
    for await (const raw of lines) {
      // Ignore a byte order mark on the very first line
      const line = lineNumber++ === 0 ? raw.replace(/^﻿/, '') : raw;
      const trimmed = line.trim();

      if (!trimmed) continue;

      const isComment = trimmed.startsWith('#') || trimmed.startsWith('%');

      if (isComment) {
        // A comment before the data may carry the column names
        if (idx === null && !headerTokens) {
          const tokens = splitTokens(trimmed.replace(/^[#%]+\s*/, ''));

          if (looksLikeHeader(tokens) && matchesAnyAlias(tokens)) {
            headerTokens = tokens;
          }
        }

        continue;
      }

      const tokens = splitTokens(trimmed);

      // First line that is not a comment: header or data? Decide the layout.
      if (idx === null) {
        if (!headerTokens && looksLikeHeader(tokens)) {
          headerTokens = tokens;
          continue;
        }

        if (headerTokens) {
          idx = resolveHeader(headerTokens);
        } else {
          if (tokens.length !== 4) {
            throw new Error(
              `No header found. Expected 4 columns (t x y p), found ${tokens.length}`
            );
          }

          idx = { t: 0, x: 1, y: 2, p: 3 };
        }

        needed = Math.max(idx.t, idx.x, idx.y, idx.p) + 1;
        // fall through: this line is data
      }

      if (tokens.length < needed) {
        skippedRows++;
        continue;
      }

      const t = tokens[idx.t] === '' ? NaN : Number(tokens[idx.t]);
      const x = tokens[idx.x] === '' ? NaN : Number(tokens[idx.x]);
      const y = tokens[idx.y] === '' ? NaN : Number(tokens[idx.y]);
      const p = tokens[idx.p] === '' ? NaN : Number(tokens[idx.p]);

      if (
        Number.isFinite(t) &&
        Number.isFinite(x) &&
        Number.isFinite(y) &&
        Number.isFinite(p)
      ) {
        events.push({
          t,
          x: Math.floor(x),
          y: Math.floor(y),
          p: Math.floor(p)
        });
      } else {
        skippedRows++;
      }
    }
  } finally {
    lines.close();
    input.destroy();
  }

  // A header was found but no data followed (or the file had no content)
  if (idx === null) {
    if (headerTokens) {
      // Validate the header so a wrong one still gives a clear error
      resolveHeader(headerTokens);
    }

    throw new Error('File is empty or contains only comments');
  }

  // Rows that could not be read are counted, never dropped silently.
  events.skippedRows = skippedRows;

  return events;
}