import path from 'node:path';
import fs from 'node:fs/promises';

import { parseFile } from './parser.js';
import { validateEvents } from '../utils/validation.js';
import { buildMetadata } from '../utils/metadata.js';
import {
  toColumns,
  isSortedByTime,
  sortColumns,
  previewRows
} from '../utils/columns.js';
import { writeHdf5 } from '../writers/hdf5.writer.js';
import { writeParquet } from '../writers/parquet.writer.js';
import { verifyOutputs } from '../utils/output-verification.js';
import { generateMetadata } from '../utils/evaa-metadata/index.js';

const MB = 1024 * 1024;

/*
 * Safety net: the whole input is read into memory (about 290 bytes per
 * event), so a very large file would run the process out of memory and
 * crash the worker. ingest() refuses input files above this size unless
 * options.maxInputBytes says otherwise (pass Infinity to switch it off).
 *
 * The EVAA backend rejects files above 100 MB before they get here; this
 * default is higher on purpose and only protects against mistakes.
 * Raise it once streaming ingest exists.
 */
export const DEFAULT_MAX_INPUT_BYTES = 250 * MB;

const round = (value) => Number(value.toFixed(2));

const perSecond = (count, ms) =>
  ms > 0 ? round((count * 1000) / ms) : null;

// Runs an async or sync step and returns its result with the time taken.
async function timed(step) {
  const start = performance.now();
  const value = await step();

  return { value, ms: performance.now() - start };
}

export async function ingest(
  inputPath,
  outputDir,
  options = {}
) {
  if (!inputPath) {
    throw new Error('inputPath is required');
  }

  if (!outputDir) {
    throw new Error('outputDir is required');
  }

  // Refuse oversized input before reading it. If the file cannot be
  // inspected here, the parser reports the real problem as before.
  const maxInputBytes = options.maxInputBytes ?? DEFAULT_MAX_INPUT_BYTES;
  const inputStat = await fs.stat(inputPath).catch(() => null);

  if (inputStat && inputStat.size > maxInputBytes) {
    throw new Error(
      `Input file is too large for this engine version: ${round(
        inputStat.size / MB
      )} MB (maximum ${round(maxInputBytes / MB)} MB). ` +
        'Very large files need streaming ingest, which is not built yet.'
    );
  }

  const totalStart = performance.now();

  const format = path
    .extname(inputPath)
    .replace('.', '')
    .toLowerCase();

  if (options.log !== false) {
    console.log(`[EVAA] Ingesting: ${inputPath}`);
    console.log(`[EVAA] Format: ${format}`);
  }

  // Parse and validate
  const parsed = await timed(() => parseFile(inputPath));
  const events = parsed.value;

  const validation = await timed(() => validateEvents(events));

  const metadata = buildMetadata(events, format, options);
  metadata.timestampUnit = options.timestampUnit ?? 'unknown';
  if (metadata.timestampUnit !== 'microseconds') metadata.durationUs = null;

  if (events.skippedRows > 0) {
    metadata.skippedRows = events.skippedRows;
  }

  // Compact columns, sorted by time
  const prepared = await timed(() => {
    let cols = toColumns(events);

    metadata.sortedInput = isSortedByTime(cols.t);

    if (!metadata.sortedInput) {
      cols = sortColumns(cols);
    }

    return cols;
  });
  const columns = prepared.value;

  // Write the output files
  await fs.mkdir(outputDir, { recursive: true });

  const hdf5Path = path.join(outputDir, 'events.h5');
  const parquetPath = path.join(outputDir, 'data.parquet');

  const hdf5 = await timed(() =>
    writeHdf5(columns, hdf5Path, metadata)
  );
  const parquet = await timed(() =>
    writeParquet(columns, parquetPath)
  );

  // Read both files back and compare with the input
  const verification = await timed(() =>
    verifyOutputs({
      hdf5Path,
      parquetPath,
      columns,
      eventCount: columns.n
    })
  );

  const [hdf5Stat, parquetStat] = await Promise.all([
    fs.stat(hdf5Path),
    fs.stat(parquetPath)
  ]);

  if (hdf5Stat.size === 0 || parquetStat.size === 0) {
    throw new Error(
      'Output verification failed: an output file is empty'
    );
  }

  const totalMs = performance.now() - totalStart;

  const benchmark = {
    parsing: {
      durationMs: round(parsed.ms),
      eventsPerSecond: perSecond(columns.n, parsed.ms)
    },
    validationMs: round(validation.ms),
    transformMs: round(prepared.ms),
    hdf5WriteMs: round(hdf5.ms),
    parquetWriteMs: round(parquet.ms),
    verificationMs: round(verification.ms),
    total: {
      durationMs: round(totalMs),
      eventsPerSecond: perSecond(columns.n, totalMs)
    },
    memory: {
      metric: 'peak RSS of this process (process.resourceUsage().maxRSS)',
      peakMB: round(process.resourceUsage().maxRSS / 1024)
    },
    outputFiles: {
      hdf5MB: round(hdf5Stat.size / MB),
      parquetMB: round(parquetStat.size / MB)
    },
    outputCorrectness: verification.value
  };

  if (options.log !== false && options.benchmarkLog) {
    console.log('[EVAA] Benchmark:', JSON.stringify(benchmark));
  }

  // Detailed metadata report (evaa-metadata). It is extra information and
  // must never make a good conversion fail, so any error is turned into
  // report: null. Switch it off with options.metadataReport = false.
  let report = null;

  if (options.metadataReport !== false) {
    try {
      report = await generateMetadata({
        filePath: inputPath,
        originalFileName: options.originalFileName,
        fileSizeBytes: inputStat ? inputStat.size : undefined,
        format,
        columns,
        options: {
          // Never infer timestamp units from numeric magnitude. Callers must
          // supply timestampUnit when the source convention is known.
          timestampUnit: options.timestampUnit ?? 'unknown',
          width: options.width,
          height: options.height,
          resolutionSource:
            options.width && options.height ? 'provided' : undefined,
          resolutionVerified: options.resolutionVerified === true,
          // columns were sorted above; report the order of the INPUT.
          inputSorted: metadata.sortedInput,
          skippedRowCount: events.skippedRows ?? 0
        },
        processingStatus: 'success',
        processingDurationMs: totalMs,
        timings: {
          parsingMs: parsed.ms,
          hdf5WritingMs: hdf5.ms,
          parquetWritingMs: parquet.ms,
          totalIngestionMs: totalMs
        },
        memory: {
          // resourceUsage().maxRSS is in kilobytes
          peakBytes: process.resourceUsage().maxRSS * 1024
        },
        outputFiles: {
          input: { sizeBytes: inputStat ? inputStat.size : null },
          hdf5: { path: hdf5Path, sizeBytes: hdf5Stat.size },
          parquet: { path: parquetPath, sizeBytes: parquetStat.size },
          validationStatus: verification.value.passed ? 'passed' : 'failed'
        },
        validation: {
          status: 'passed',
          outputCorrectness: verification.value.passed === true
        }
      });
    } catch (error) {
      report = null;

      if (options.log !== false) {
        console.warn(
          `[EVAA] Metadata report skipped: ${error.message}`
        );
      }
    }
  }

  return {
    success: true,

    metadata,

    report,

    preview: previewRows(columns, 10),

    eventCount: columns.n,

    files: [
      { kind: 'HDF5', path: hdf5Path },
      { kind: 'PARQUET', path: parquetPath }
    ],

    benchmark
  };
}