export {
  generateMetadata,
  extractEventMetadata,
  createEventAccumulator,
  buildFileMetadata,
  buildPerformanceMetadata,
  timestampToSeconds
} from './metadata.js';

export { METADATA_SCHEMA_VERSION } from './constants.js';