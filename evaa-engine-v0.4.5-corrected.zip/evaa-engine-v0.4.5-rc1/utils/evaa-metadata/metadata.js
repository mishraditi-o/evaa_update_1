/*
 * EVAA metadata report.
 *
 * Based on Aditi's evaa-metadata package. The report has the same shape as
 * before; what changed is how it is calculated:
 *
 *  - The original extractEventMetadata() needed every event as an object in
 *    an array, plus a copy of all timestamps and a sorted copy. That used
 *    about 700 MB for 5.7 million events (a 100 MB CSV) and tens of GB for a
 *    15 GB file.
 *  - The report is now built by an accumulator that sees each event once and
 *    keeps only counters. Memory no longer grows with the number of events
 *    (the only growing part is the set of active pixels, which is bounded by
 *    the sensor size).
 *  - extractEventMetadata(events) still works and returns the same report,
 *    so existing callers and tests keep working.
 *
 * The accumulator can be fed one event at a time (add), a block of columns
 * (addColumns), or batch after batch from a streaming reader.
 */

import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";

import {
  METADATA_SCHEMA_VERSION,
  SUPPORTED_FORMATS,
  TIMESTAMP_UNITS_PER_SECOND
} from "./constants.js";

const isFiniteNumber = (value) =>
  typeof value === "number" && Number.isFinite(value);

const round = (value, digits = 6) => {
  if (!isFiniteNumber(value)) return null;

  return Number(value.toFixed(digits));
};

const getFormat = (filename = "") =>
  path.extname(filename).slice(1).toLowerCase();

// A sensor bigger than this many pixels is tracked with a Set instead of a
// bitmap (a bitmap of this size is 64 MB).
const MAX_BITMAP_PIXELS = 64 * 1024 * 1024;

export function timestampToSeconds(duration, unit) {
  const factor = TIMESTAMP_UNITS_PER_SECOND[unit];

  if (!isFiniteNumber(duration) || !factor) {
    return null;
  }

  return duration / factor;
}

export async function buildFileMetadata({
  filePath,
  originalFileName,
  fileSizeBytes,
  format,
  processingStatus = "success",
  processingDurationMs = null
} = {}) {
  const filename =
    originalFileName ||
    (filePath ? path.basename(filePath) : null);

  let size = isFiniteNumber(fileSizeBytes)
    ? fileSizeBytes
    : null;

  if (size === null && filePath) {
    try {
      const stats = await fs.stat(filePath);
      size = stats.size;
    } catch {
      // File size remains unavailable if the file cannot be accessed.
    }
  }

  const detectedFormat = (
    format || getFormat(filename || filePath || "")
  ).toLowerCase();

  return {
    fileName: filename,
    format: detectedFormat
      ? detectedFormat.toUpperCase()
      : null,

    supportedFormat: SUPPORTED_FORMATS.has(detectedFormat),

    fileSizeBytes: size,

    fileSizeMB: size === null
      ? null
      : round(size / (1024 * 1024), 4),

    processingStatus,

    processingDurationMs:
      isFiniteNumber(processingDurationMs) &&
      processingDurationMs >= 0
        ? round(processingDurationMs, 3)
        : null
  };
}

/**
 * Collects event statistics one event (or one block of events) at a time.
 *
 * options (all optional):
 *   timestampUnit      "seconds" | "milliseconds" | "microseconds" | "nanoseconds"
 *   width, height      verified or supplied sensor size
 *   resolutionSource, resolutionVerified, missingRowCount, skippedRowCount
 *   inputSorted        true/false: whether the ORIGINAL input was in time
 *                      order, for callers that sort before reporting. When
 *                      left out, the order in which events arrive is used.
 */
export function createEventAccumulator(options = {}) {
  const suppliedWidth =
    Number.isInteger(options.width) && options.width > 0
      ? options.width
      : null;

  const suppliedHeight =
    Number.isInteger(options.height) && options.height > 0
      ? options.height
      : null;

  const useBitmap =
    suppliedWidth !== null &&
    suppliedHeight !== null &&
    suppliedWidth * suppliedHeight <= MAX_BITMAP_PIXELS;

  const bitmap = useBitmap
    ? new Uint8Array(suppliedWidth * suppliedHeight)
    : null;

  // Pixels outside the supplied sensor size (or all pixels when no size was
  // supplied) are tracked here by a numeric key.
  const otherPixels = new Set();
  let bitmapActive = 0;

  let totalSeen = 0;
  let validEventCount = 0;
  let invalidEventCount = 0;

  let minT = Infinity;
  let maxT = -Infinity;
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;

  let positiveEventCount = 0;
  let negativeEventCount = 0;
  let zeroPolarityCount = 0;

  // Order of arrival: needed to know whether the gaps below are exact.
  let arrivalSorted = true;
  let previousT = -Infinity;

  let gapCount = 0;
  let minGap = Infinity;
  let maxGap = -Infinity;
  let gapSum = 0;

  function markActive(x, y) {
    if (bitmap !== null && x < suppliedWidth && y < suppliedHeight) {
      const index = y * suppliedWidth + x;

      if (bitmap[index] === 0) {
        bitmap[index] = 1;
        bitmapActive++;
      }

      return;
    }

    // x, y are normally 16-bit; fall back to a string key for odd input.
    const key =
      x <= 65535 && y <= 65535 ? x * 65536 + y : `${x},${y}`;

    otherPixels.add(key);
  }

  function add(t, x, y, p) {
    totalSeen++;

    const valid =
      isFiniteNumber(t) &&
      Number.isInteger(x) &&
      Number.isInteger(y) &&
      isFiniteNumber(p) &&
      x >= 0 &&
      y >= 0 &&
      (p === -1 || p === 0 || p === 1) &&
      (suppliedWidth === null || x < suppliedWidth) &&
      (suppliedHeight === null || y < suppliedHeight);

    if (!valid) {
      invalidEventCount++;
      return;
    }

    validEventCount++;

    if (t < previousT) {
      arrivalSorted = false;
    } else if (previousT !== -Infinity) {
      const gap = t - previousT;

      gapCount++;
      gapSum += gap;
      if (gap < minGap) minGap = gap;
      if (gap > maxGap) maxGap = gap;
    }

    previousT = t;

    if (t < minT) minT = t;
    if (t > maxT) maxT = t;
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;

    if (p > 0) positiveEventCount++;
    else if (p < 0) negativeEventCount++;
    else zeroPolarityCount++;

    markActive(x, y);
  }

  // Adds a block of events stored as columns (typed arrays or plain arrays).
  // `columns.n` is the number of events; start/end select a slice.
  function addColumns(columns, start = 0, end = columns.n) {
    const { t, x, y, p } = columns;

    for (let i = start; i < end; i++) {
      add(t[i], x[i], y[i], p[i]);
    }
  }

  /**
   * Builds the report. `gapOverride` is for callers that had to sort the
   * timestamps themselves because events arrived out of order:
   * { count, min, max, sum }.
   */
  function finish(gapOverride = null) {
    const hasEvents = validEventCount > 0;

    const timestampUnit =
      TIMESTAMP_UNITS_PER_SECOND[options.timestampUnit]
        ? options.timestampUnit
        : "unknown";

    const sortedInput =
      typeof options.inputSorted === "boolean"
        ? options.inputSorted
        : arrivalSorted;

    const minTimestamp = hasEvents ? minT : null;
    const maxTimestamp = hasEvents ? maxT : null;
    const duration = hasEvents ? maxT - minT : null;

    const durationSeconds =
      duration === null
        ? null
        : timestampToSeconds(duration, timestampUnit);

    // Prefer verified sensor dimensions supplied by the caller.
    // Coordinate-derived dimensions are estimates, not sensor truth.
    const width = suppliedWidth ?? (hasEvents ? maxX + 1 : null);
    const height = suppliedHeight ?? (hasEvents ? maxY + 1 : null);

    const resolutionSource =
      suppliedWidth !== null && suppliedHeight !== null
        ? (options.resolutionSource || "provided")
        : "inferred_from_event_coordinates";

    const resolutionVerified = options.resolutionVerified === true;

    const sensorPixelCount =
      width !== null && height !== null ? width * height : null;

    const activePixelCount = bitmapActive + otherPixels.size;

    const coverage =
      sensorPixelCount > 0 ? activePixelCount / sensorPixelCount : null;

    const eventRate =
      durationSeconds > 0 ? validEventCount / durationSeconds : null;

    const nonZeroPolarityCount =
      positiveEventCount + negativeEventCount;

    const positiveNegativeRatio = {
      positive:
        nonZeroPolarityCount > 0
          ? round(positiveEventCount / nonZeroPolarityCount)
          : null,

      negative:
        nonZeroPolarityCount > 0
          ? round(negativeEventCount / nonZeroPolarityCount)
          : null,

      positiveToNegative:
        negativeEventCount > 0
          ? round(positiveEventCount / negativeEventCount)
          : null
    };

    // Gaps between neighbouring timestamps in time order. They are exact
    // when the events arrived in time order, or when the caller sorted the
    // timestamps itself and passed the result in as gapOverride.
    let gaps = null;

    if (arrivalSorted) {
      gaps = { count: gapCount, min: minGap, max: maxGap, sum: gapSum };
    } else if (gapOverride) {
      gaps = gapOverride;
    }

    const warnings = [];

    if (timestampUnit === "unknown") {
      warnings.push(
        "Timestamp unit is unknown; event rate and duration in seconds are unavailable."
      );
    }

    if (!resolutionVerified) {
      warnings.push(
        "Sensor resolution is unverified; spatial coverage may use estimated dimensions."
      );
    }

    if (!sortedInput) {
      warnings.push("Input events are not ordered by timestamp.");
    }

    if (!arrivalSorted && !gapOverride) {
      warnings.push(
        "Timestamp gap statistics were skipped because events arrived out of time order."
      );
    }

    if (invalidEventCount > 0) {
      warnings.push(
        "Invalid events were excluded from event-based calculations."
      );
    }

    const eventDistribution = {
      eventsPerPolarity: {
        positive: positiveEventCount,
        negative: negativeEventCount,
        zero: zeroPolarityCount
      },

      timestampGap:
        gaps && gaps.count > 0
          ? {
              mean: round(gaps.sum / gaps.count),
              min: gaps.min,
              max: gaps.max
            }
          : null
    };

    const polarityValues = [];
    if (negativeEventCount > 0) polarityValues.push(-1);
    if (zeroPolarityCount > 0) polarityValues.push(0);
    if (positiveEventCount > 0) polarityValues.push(1);

    return {
      eventModel: ["t", "x", "y", "p"],

      eventCount: totalSeen,
      validEventCount,
      invalidEventCount,

      sensor: {
        width,
        height,
        resolutionSource,
        resolutionVerified,

        coordinateBounds: hasEvents
          ? { minX, maxX, minY, maxY }
          : null,

        activePixelCount,
        sensorPixelCount,

        // Sparsity is the inactive fraction; coverage is its complement.
        activePixelSparsity:
          coverage === null ? null : round(1 - coverage),

        activePixelSparsityPercent:
          coverage === null ? null : round((1 - coverage) * 100, 4),

        spatialCoverage:
          coverage === null ? null : round(coverage),

        spatialCoveragePercent:
          coverage === null ? null : round(coverage * 100, 4),

        coverageDenominator: resolutionVerified
          ? "verified_sensor_area"
          : "estimated_or_unverified_sensor_area"
      },

      timestamps: {
        unit: timestampUnit,

        unitStatus:
          timestampUnit === "unknown" ? "unverified" : "provided",

        minTimestamp,
        maxTimestamp,

        duration: duration === null ? null : round(duration),

        durationSeconds:
          durationSeconds === null ? null : round(durationSeconds),

        durationUs:
          timestampUnit === "microseconds" && duration !== null
            ? round(duration)
            : null,

        sortedInput,
        outOfOrderDetected: !sortedInput
      },

      polarity: {
        values: polarityValues,

        positiveEventCount,
        negativeEventCount,
        zeroPolarityCount,

        positiveNegativeRatio
      },

      analytics: {
        eventRatePerSecond:
          eventRate === null ? null : round(eventRate, 3),

        averageEventsPerSecond:
          eventRate === null ? null : round(eventRate, 3),

        spatialCoveragePercent:
          coverage === null ? null : round(coverage * 100, 4),

        eventDistribution
      },

      dataQuality: {
        status:
          invalidEventCount === 0 ? "valid" : "invalid_events_detected",

        invalidEventCount,

        missingRowCount: Number.isInteger(options.missingRowCount)
          ? options.missingRowCount
          : null,

        skippedRowCount: Number.isInteger(options.skippedRowCount)
          ? options.skippedRowCount
          : null,

        warnings
      }
    };
  }

  return { add, addColumns, finish };
}

/**
 * Same function and result as the original package: takes an array of
 * { t, x, y, p } objects. It now uses the accumulator, so it no longer
 * keeps extra copies of the timestamps.
 */
export function extractEventMetadata(events, options = {}) {
  if (!Array.isArray(events)) {
    throw new TypeError(
      "events must be an array of { t, x, y, p } objects"
    );
  }

  const accumulator = createEventAccumulator(options);

  let previousT = -Infinity;
  let ordered = true;

  for (const event of events) {
    if (event) {
      accumulator.add(event.t, event.x, event.y, event.p);

      if (isFiniteNumber(event.t)) {
        if (event.t < previousT) ordered = false;
        previousT = event.t;
      }
    } else {
      accumulator.add(NaN, NaN, NaN, NaN);
    }
  }

  // Out-of-order arrays still get exact gap statistics: sort the
  // timestamps only (8 bytes per event), not the whole events.
  let gapOverride = null;

  if (!ordered) {
    const timestamps = [];

    for (const event of events) {
      if (
        event &&
        isFiniteNumber(event.t) &&
        Number.isInteger(event.x) &&
        Number.isInteger(event.y) &&
        isFiniteNumber(event.p) &&
        event.x >= 0 &&
        event.y >= 0 &&
        (event.p === -1 || event.p === 0 || event.p === 1)
      ) {
        timestamps.push(event.t);
      }
    }

    const sorted = Float64Array.from(timestamps).sort();

    let sum = 0;
    let min = Infinity;
    let max = -Infinity;

    for (let i = 1; i < sorted.length; i++) {
      const gap = sorted[i] - sorted[i - 1];

      sum += gap;
      if (gap < min) min = gap;
      if (gap > max) max = gap;
    }

    gapOverride = { count: Math.max(0, sorted.length - 1), min, max, sum };
  }

  return accumulator.finish(gapOverride);
}

export function buildPerformanceMetadata({
  timings = {},
  memory = {},
  outputFiles = {},
  transfer = {},
  recordingDurationSeconds = null
} = {}) {
  const getTiming = (key) =>
    isFiniteNumber(timings[key]) && timings[key] >= 0
      ? round(timings[key], 3)
      : null;

  const getFileSize = (key) =>
    isFiniteNumber(outputFiles[key]?.sizeBytes)
      ? outputFiles[key].sizeBytes
      : null;

  const totalMs = getTiming("totalIngestionMs");

  const processingSeconds =
    totalMs === null ? null : totalMs / 1000;

  const realTimeFactor =
    isFiniteNumber(recordingDurationSeconds) &&
    recordingDurationSeconds >= 0 &&
    processingSeconds > 0
      ? round(recordingDurationSeconds / processingSeconds, 6)
      : null;

  const peakBandwidth =
    isFiniteNumber(transfer.bytesTransferred) &&
    isFiniteNumber(transfer.durationSeconds) &&
    transfer.bytesTransferred >= 0 &&
    transfer.durationSeconds > 0
      ? round(
          transfer.bytesTransferred / transfer.durationSeconds,
          3
        )
      : null;

  return {
    parsingDurationMs: getTiming("parsingMs"),
    hdf5WritingDurationMs: getTiming("hdf5WritingMs"),
    parquetWritingDurationMs: getTiming("parquetWritingMs"),
    totalIngestionDurationMs: totalMs,

    eventsProcessedPerSecond:
      isFiniteNumber(timings.eventCount) && processingSeconds > 0
        ? round(timings.eventCount / processingSeconds, 3)
        : null,

    peakMemoryBytes:
      isFiniteNumber(memory.peakBytes) ? memory.peakBytes : null,

    peakMemoryMB:
      isFiniteNumber(memory.peakBytes)
        ? round(memory.peakBytes / (1024 * 1024), 3)
        : null,

    inputFileSizeBytes: getFileSize("input"),
    hdf5OutputSizeBytes: getFileSize("hdf5"),
    parquetOutputSizeBytes: getFileSize("parquet"),

    outputValidationStatus: outputFiles.validationStatus ?? null,

    realTimeFactor,

    realTimeFactorStatus:
      realTimeFactor === null
        ? "unavailable_missing_valid_durations"
        : realTimeFactor > 1
          ? "faster_than_real_time"
          : "real_time_or_slower",

    peakBandwidthBytesPerSecond: peakBandwidth,

    peakBandwidthStatus:
      peakBandwidth === null
        ? "unavailable_missing_transfer_measurements"
        : "measured"
  };
}

/**
 * Builds the complete report. Give it EITHER `events` (array of objects)
 * OR `columns` ({ n, t, x, y, p } typed arrays, as the engine uses them).
 * `columns` is the memory-friendly choice for large files.
 */
export async function generateMetadata({
  filePath,
  originalFileName,
  fileSizeBytes,
  format,
  events,
  columns,
  options = {},
  processingStatus = "success",
  processingDurationMs = null,
  timings = {},
  memory = {},
  outputFiles = {},
  transfer = {},
  validation = {}
} = {}) {
  const file = await buildFileMetadata({
    filePath,
    originalFileName,
    fileSizeBytes,
    format,
    processingStatus,
    processingDurationMs
  });

  let eventMetadata;

  if (columns) {
    const accumulator = createEventAccumulator(options);
    accumulator.addColumns(columns);
    eventMetadata = accumulator.finish();
  } else {
    eventMetadata = extractEventMetadata(events || [], options);
  }

  const performance = buildPerformanceMetadata({
    timings: {
      ...timings,
      eventCount: eventMetadata.validEventCount
    },
    memory,
    outputFiles,
    transfer,
    recordingDurationSeconds: eventMetadata.timestamps.durationSeconds
  });

  return {
    schemaVersion: METADATA_SCHEMA_VERSION,
    generatedAt: new Date().toISOString(),

    file,
    ...eventMetadata,
    performance,

    outputFiles: {
      hdf5: outputFiles.hdf5?.path ?? null,
      parquet: outputFiles.parquet?.path ?? null
    },

    validation: {
      status:
        validation.status ??
        (eventMetadata.dataQuality.status === "valid"
          ? "passed"
          : "failed"),

      message: validation.message ?? null,

      outputCorrectness:
        validation.outputCorrectness ??
        outputFiles.validationStatus ??
        null
    },

    integration: {
      source: "evaa-metadata",
      runtime: `node ${process.version}`,
      platform: os.platform()
    }
  };
}