import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import PDFDocument from 'pdfkit';

/*
 * Renders an analysis report (see build-report.js) as an A4 PDF.
 *
 *   const pdf = await renderReportPdf(report, { charts });
 *
 * `charts` is optional and comes from visualize():
 *   { eventRate: { binUs, on[], off[] }, heatmap: { gridW, gridH, max, values[] } }
 * Without it the report simply has no chart section.
 *
 * Font: Inter (SIL Open Font License, see fonts/OFL.txt), embedded in the PDF.
 * If the font files are missing it falls back to Helvetica.
 */

const PAGE_W = 595.28;
const PAGE_H = 841.89;
const M = 44; // page margin
const W = PAGE_W - 2 * M; // content width
const BOTTOM = PAGE_H - 64; // lowest y for content
const NEXT_PAGE_TOP = 78; // where content starts on pages after the first

const C = {
  ink: '#0F172A',
  body: '#334155',
  muted: '#64748B',
  faint: '#94A3B8',
  line: '#E2E8F0',
  panel: '#F8FAFC',
  accent: '#E8730C',
  accentDark: '#C2410C',
  blue: '#2563EB',
  slate: '#64748B',
  ok: '#15803D',
  okSoft: '#DCFCE7',
  warn: '#B45309',
  warnSoft: '#FEF3C7',
  info: '#1D4ED8',
  infoSoft: '#DBEAFE'
};

const NA = 'Not available';

// ---- fonts -------------------------------------------------------------

const FONT_DIR = path.join(
  path.dirname(fileURLToPath(import.meta.url)),
  'fonts'
);
const FONT_FILES = {
  regular: 'inter-latin-400-normal.woff',
  medium: 'inter-latin-500-normal.woff',
  semibold: 'inter-latin-600-normal.woff',
  bold: 'inter-latin-700-normal.woff'
};
const FALLBACK = {
  regular: 'Helvetica',
  medium: 'Helvetica',
  semibold: 'Helvetica-Bold',
  bold: 'Helvetica-Bold'
};

let fontBuffers; // read once, reused for every report

function loadFontBuffers() {
  if (fontBuffers !== undefined) return fontBuffers;
  try {
    fontBuffers = {};
    for (const [key, file] of Object.entries(FONT_FILES)) {
      fontBuffers[key] = fs.readFileSync(path.join(FONT_DIR, file));
    }
  } catch {
    fontBuffers = null; // font files missing: use Helvetica
  }
  return fontBuffers;
}

function registerFonts(doc) {
  const buffers = loadFontBuffers();
  if (!buffers) return FALLBACK;

  const names = {};
  for (const key of Object.keys(FONT_FILES)) {
    names[key] = `Inter-${key}`;
    doc.registerFont(names[key], buffers[key]);
  }
  return names;
}

// ---- formatting --------------------------------------------------------

const n = (v, suffix = '', digits) => {
  if (v === null || v === undefined) return NA;
  const text =
    digits === undefined
      ? v.toLocaleString('en-US')
      : v.toLocaleString('en-US', {
          minimumFractionDigits: digits,
          maximumFractionDigits: digits
        });
  return `${text}${suffix}`;
};

const t = (v) => (v ? v : NA);

const compact = (v) => {
  const trim = (x) => x.toFixed(1).replace(/\.0$/, '');
  if (v >= 1e9) return `${trim(v / 1e9)}G`;
  if (v >= 1e6) return `${trim(v / 1e6)}M`;
  if (v >= 1e3) return `${trim(v / 1e3)}k`;
  return String(Math.round(v));
};

const duration = (seconds) => {
  if (seconds === null || seconds === undefined) return NA;
  if (seconds >= 60) return `${(seconds / 60).toFixed(1)} min`;
  if (seconds >= 1) return `${seconds.toFixed(2)} s`;
  return `${(seconds * 1000).toFixed(1)} ms`;
};

const RESOLUTION_TEXT = {
  verified: 'Verified',
  provided: 'Provided, not verified',
  estimated: 'Estimated from the data'
};

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

// ---- main --------------------------------------------------------------

export function renderReportPdf(report, options = {}) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      margins: { top: NEXT_PAGE_TOP, bottom: 0, left: M, right: M },
      bufferPages: true,
      info: {
        Title: `EVAA Analysis Report - ${report.dataset.name}`,
        Author: 'EVAA - Zoove Space',
        Subject: 'Event camera dataset analysis'
      }
    });

    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    try {
      draw(doc, report, options.charts ?? {});
      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

function draw(doc, report, charts) {
  const F = registerFonts(doc);
  let y = 0;

  const newPage = () => {
    doc.addPage();
    y = NEXT_PAGE_TOP;
  };
  const ensure = (height) => {
    if (y + height > BOTTOM) newPage();
  };

  // ---- small drawing helpers ------------------------------------------

  const text = (value, x, ty, opts = {}) => {
    const {
      font = 'regular',
      size = 10,
      color = C.body,
      ...rest
    } = opts;
    doc.font(F[font]).fontSize(size).fillColor(color);
    doc.text(value, x, ty, { lineBreak: false, ...rest });
  };

  const logo = (x, ty, size) => {
    doc.roundedRect(x, ty, size, size, size * 0.24).fill(C.accent);
    doc.lineWidth(size * 0.08).lineCap('round').strokeColor('#FFFFFF');
    for (const k of [0.3, 0.5, 0.7]) {
      const w = k === 0.5 ? 0.46 : 0.34;
      doc
        .moveTo(x + size * 0.28, ty + size * k)
        .lineTo(x + size * (0.28 + w), ty + size * k)
        .stroke();
    }
    doc.lineCap('butt');
  };

  // `needs` = height of the content that must stay on the same page as the heading
  const sectionTitle = (title, subtitle, needs = 60) => {
    ensure(38 + needs);
    doc.rect(M, y + 1, 3, 15).fill(C.accent);
    text(title, M + 11, y, { font: 'bold', size: 13, color: C.ink });
    if (subtitle) {
      text(subtitle, M + 11, y + 17, { size: 8.5, color: C.muted });
      y += 38;
    } else {
      y += 28;
    }
  };

  /* A block of "label ........ value" rows. Returns its height. */
  const keyValues = (x, top, width, title, rows) => {
    text(title.toUpperCase(), x, top, {
      font: 'semibold',
      size: 7.5,
      color: C.faint,
      characterSpacing: 1
    });
    let ry = top + 18;
    rows.forEach(([label, value], i) => {
      if (i % 2 === 0) {
        doc.rect(x, ry - 4, width, 22).fill(C.panel);
      }
      text(label, x + 8, ry + 1, { size: 9, color: C.muted });
      text(value, x + 8, ry + 1, {
        font: 'semibold',
        size: 9,
        color: C.ink,
        width: width - 16,
        align: 'right'
      });
      ry += 22;
    });
    return ry - top;
  };

  const pill = (label, x, py, color, bg) => {
    doc.font(F.semibold).fontSize(8);
    const w = doc.widthOfString(label) + 20;
    doc.roundedRect(x, py, w, 18, 9).fill(bg);
    doc.circle(x + 10, py + 9, 2.5).fill(color);
    text(label, x + 17, py + 5, { font: 'semibold', size: 8, color });
    return w;
  };

  // ======================================================================
  // Page 1: header band
  // ======================================================================
  doc.rect(0, 0, PAGE_W, 156).fill(C.ink);
  doc.rect(0, 0, PAGE_W, 5).fill(C.accent);

  logo(M, 30, 26);
  text('EVAA', M + 36, 33, { font: 'bold', size: 15, color: '#FFFFFF' });
  text('EVENT VISION ANALYSIS', M + 36, 51, {
    size: 7,
    color: C.faint,
    characterSpacing: 1.4
  });

  const generated = report.generatedAt.replace('T', ' ').slice(0, 16) + ' UTC';
  text('GENERATED', M, 33, {
    size: 7,
    color: C.faint,
    characterSpacing: 1.2,
    width: W,
    align: 'right'
  });
  text(generated, M, 44, {
    font: 'medium',
    size: 9,
    color: '#E2E8F0',
    width: W,
    align: 'right'
  });

  text('Analysis Report', M, 80, {
    font: 'bold',
    size: 30,
    color: '#FFFFFF'
  });
  text(report.dataset.name || report.dataset.fileName, M, 120, {
    font: 'medium',
    size: 12,
    color: '#CBD5E1',
    width: W * 0.62,
    ellipsis: true
  });
  text(
    `${report.dataset.fileName}  ·  ${report.dataset.format}`,
    M,
    136,
    { size: 8.5, color: C.faint, width: W * 0.62, ellipsis: true }
  );

  if (report.quality.validationStatus) {
    const ok = report.quality.validationStatus === 'valid';
    const label = ok ? 'All events valid' : 'Some events excluded';
    doc.font(F.semibold).fontSize(8);
    const w = doc.widthOfString(label) + 20;
    pill(label, PAGE_W - M - w, 124, ok ? C.ok : C.warn, ok ? C.okSoft : C.warnSoft);
  }

  // ---- KPI tiles (overlap the header) ---------------------------------
  const s = report.summary;
  const q = report.quality;
  const kpis = [
    [
      'EVENTS',
      n(s.eventCount),
      q.completenessPercent !== null
        ? `${q.completenessPercent}% valid`
        : 'event count'
    ],
    ['DURATION', duration(s.durationSeconds), t(s.timestampUnit) + ' timestamps'],
    [
      'SENSOR',
      s.sensorWidth !== null && s.sensorHeight !== null
        ? `${s.sensorWidth} × ${s.sensorHeight}`
        : NA,
      s.resolutionSource ? RESOLUTION_TEXT[s.resolutionSource] : 'resolution'
    ],
    [
      'AVG. RATE',
      s.averageRateEventsPerSecond === null
        ? NA
        : compact(s.averageRateEventsPerSecond),
      'events per second'
    ]
  ];
  const gap = 10;
  const tileW = (W - gap * 3) / 4;
  const tileY = 132 + 40;
  kpis.forEach(([label, value, sub], i) => {
    const x = M + i * (tileW + gap);
    // soft shadow, then the card
    doc.roundedRect(x, tileY - 22 + 2, tileW, 66, 8).fill('#E2E8F0');
    doc.roundedRect(x, tileY - 22, tileW, 66, 8).fill('#FFFFFF');
    doc.roundedRect(x, tileY - 22, tileW, 66, 8).lineWidth(0.6).stroke(C.line);
    text(label, x + 12, tileY - 12, {
      font: 'semibold',
      size: 7,
      color: C.faint,
      characterSpacing: 1
    });
    text(value, x + 12, tileY + 3, {
      font: 'bold',
      size: 17,
      color: C.ink,
      width: tileW - 20,
      ellipsis: true
    });
    text(sub, x + 12, tileY + 27, {
      size: 7.5,
      color: C.muted,
      width: tileW - 20,
      ellipsis: true
    });
  });

  y = tileY + 66;

  // ======================================================================
  // Dataset summary + data quality
  // ======================================================================
  sectionTitle('Overview', 'What was recorded and how clean the data is', 170);
  const colW = (W - 36) / 2;
  const h1 = keyValues(M, y, colW, 'Dataset summary', [
    ['File format', t(report.dataset.format)],
    ['Event count', n(s.eventCount)],
    [
      'Sensor resolution',
      s.sensorWidth !== null && s.sensorHeight !== null
        ? `${s.sensorWidth} × ${s.sensorHeight}`
        : NA
    ],
    [
      'Resolution source',
      s.resolutionSource ? RESOLUTION_TEXT[s.resolutionSource] : NA
    ],
    ['Recording duration', duration(s.durationSeconds)],
    ['Timestamp unit', t(s.timestampUnit)],
    ['Average event rate', n(s.averageRateEventsPerSecond, ' ev/s')]
  ]);
  const h2 = keyValues(M + colW + 36, y, colW, 'Data quality', [
    ['Validation status', t(q.validationStatus)],
    ['Valid events', n(q.validEvents)],
    ['Invalid events', n(q.invalidEvents)],
    ['Skipped rows', n(q.skippedRows)],
    ['Completeness', n(q.completenessPercent, '%', 2)],
    ['Timestamp ordering', t(q.timestampOrdering)]
  ]);
  y += Math.max(h1, h2) + 14;

  // ======================================================================
  // Sensor activity: coverage bar + polarity split
  // ======================================================================
  const sensor = report.sensor;
  sectionTitle(
    'Sensor activity',
    'How much of the sensor was active, and ON vs OFF events',
    130
  );

  const left = M;
  const barW = colW;

  // coverage bar
  text('SPATIAL COVERAGE', left, y, {
    font: 'semibold',
    size: 7.5,
    color: C.faint,
    characterSpacing: 1
  });
  text(n(sensor.coveragePercent, '%', 2), left, y - 2, {
    font: 'bold',
    size: 14,
    color: C.ink,
    width: barW,
    align: 'right'
  });
  const coverageY = y + 20;
  doc.roundedRect(left, coverageY, barW, 9, 4.5).fill(C.line);
  if (sensor.coveragePercent !== null) {
    const fillW = Math.max(
      barW * clamp(sensor.coveragePercent / 100, 0, 1),
      sensor.coveragePercent > 0 ? 6 : 0
    );
    if (fillW > 0) doc.roundedRect(left, coverageY, fillW, 9, 4.5).fill(C.accent);
  }
  text(
    sensor.activePixels !== null && sensor.sensorPixels !== null
      ? `${n(sensor.activePixels)} of ${n(sensor.sensorPixels)} pixels recorded events`
      : 'Pixel counts are not available',
    left,
    coverageY + 15,
    { size: 8.5, color: C.muted, width: barW }
  );

  // polarity bar
  const polY = coverageY + 44;
  text('POLARITY SPLIT', left, polY, {
    font: 'semibold',
    size: 7.5,
    color: C.faint,
    characterSpacing: 1
  });
  const barY = polY + 16;
  if (sensor.onEvents !== null && sensor.offEvents !== null) {
    const total = sensor.onEvents + sensor.offEvents;
    const onW = total ? (sensor.onEvents / total) * barW : 0;
    doc.roundedRect(left, barY, barW, 12, 6).fill(C.blue);
    if (onW > 0) {
      doc.save();
      doc.roundedRect(left, barY, barW, 12, 6).clip();
      doc.rect(left, barY, onW, 12).fill(C.accent);
      doc.restore();
    }
    doc.circle(left + 4, barY + 28, 3.5).fill(C.accent);
    text(`ON  ${n(sensor.onEvents)}  (${n(sensor.onPercent, '%', 1)})`, left + 13, barY + 23, {
      font: 'medium',
      size: 8.5,
      color: C.body
    });
    doc.circle(left + barW / 2 + 4, barY + 28, 3.5).fill(C.blue);
    text(
      `OFF  ${n(sensor.offEvents)}  (${total ? n(Math.round((sensor.offEvents / total) * 1000) / 10, '%', 1) : NA})`,
      left + barW / 2 + 13,
      barY + 23,
      { font: 'medium', size: 8.5, color: C.body }
    );
  } else {
    text('Polarity counts are not available', left, barY, {
      size: 9,
      color: C.muted
    });
  }

  const hSensor = keyValues(M + colW + 36, y, colW, 'Sensor analytics', [
    ['Active pixels', n(sensor.activePixels)],
    ['Sparsity', n(sensor.sparsityPercent, '%', 2)],
    ['Events per active pixel', n(sensor.eventsPerActivePixel, '', 2)],
    ['ON events', n(sensor.onEvents)],
    ['OFF events', n(sensor.offEvents)],
    ['Polarity format', t(sensor.polarityNote?.replace('Polarity is stored as ', ''))]
  ]);
  y += Math.max(hSensor, barY + 40 - y) + 14;

  // ======================================================================
  // Charts (optional): event rate over time, and where events landed
  // ======================================================================
  const eventRate = charts.eventRate;
  const hasRate =
    eventRate && Array.isArray(eventRate.on) && eventRate.on.length > 1;
  const heat = charts.heatmap;
  const hasHeat =
    heat && heat.gridW > 0 && heat.gridH > 0 && Array.isArray(heat.values);

  if (hasRate || hasHeat) {
    const both = hasRate && hasHeat;
    const chartW = both ? Math.round(W * 0.6) : W;
    const heatW = both ? W - chartW - 24 : Math.min(300, W * 0.62);
    const heatH = hasHeat ? heatW * (heat.gridH / heat.gridW) : 0;
    const chartH = 140;
    const blockH = Math.max(hasRate ? chartH + 6 : 0, hasHeat ? heatH + 52 : 0);

    sectionTitle(
      both ? 'Activity over time and space' : hasRate ? 'Event rate over time' : 'Where events happened',
      both
        ? 'Events per second (ON and OFF), and where events landed on the sensor'
        : hasRate
          ? 'Events per second, ON and OFF'
          : 'Event density across the sensor',
      blockH
    );

    if (hasRate) {
      drawRateChart(doc, F, { x: M, y, w: chartW, h: chartH }, eventRate);
    }

    if (hasHeat) {
      const hx = both ? M + chartW + 24 : M;
      drawHeatmap(doc, { x: hx, y: y + 6, w: heatW, h: heatH }, heat);

      const ly = y + 6 + heatH + 10;
      const steps = 40;
      for (let i = 0; i < steps; i++) {
        doc.rect(hx + (heatW * i) / steps, ly, heatW / steps + 0.5, 7).fill(heatColor(i / (steps - 1)));
      }
      text('few events', hx, ly + 11, { size: 7.5, color: C.muted });
      text('many events', hx, ly + 11, { size: 7.5, color: C.muted, width: heatW, align: 'right' });

      if (!both) {
        const cx = hx + heatW + 28;
        const cw = W - heatW - 28;
        text('DENSITY', cx, y + 6, { font: 'semibold', size: 7.5, color: C.faint, characterSpacing: 1 });
        text(
          `${heat.gridW} × ${heat.gridH} grid. The busiest cell holds ${n(heat.max)} events.`,
          cx,
          y + 22,
          { size: 8.5, color: C.muted, width: cw, lineBreak: true }
        );
      }
    }
    y += blockH + 16;
  }

  // ======================================================================
  // Processing performance
  // ======================================================================
  const perf = report.performance;
  sectionTitle('Processing performance', 'How the file was converted', 150);

  const stages = [
    ['Reading the file', perf.stages.readingSeconds, C.accent],
    ['Writing HDF5', perf.stages.hdf5Seconds, C.blue],
    ['Writing Parquet', perf.stages.parquetSeconds, C.slate]
  ].filter(([, v]) => v !== null);

  if (stages.length && perf.processingSeconds) {
    const sum = stages.reduce((a, [, v]) => a + v, 0);
    const other = Math.max(0, perf.processingSeconds - sum);
    const parts = [...stages];
    if (other > perf.processingSeconds * 0.01) {
      parts.push(['Verification and other', other, '#CBD5E1']);
    }
    const totalPart = parts.reduce((a, [, v]) => a + v, 0);

    text('TIME PER STAGE', M, y, {
      font: 'semibold',
      size: 7.5,
      color: C.faint,
      characterSpacing: 1
    });
    text(duration(perf.processingSeconds), M, y - 2, {
      font: 'bold',
      size: 14,
      color: C.ink,
      width: W,
      align: 'right'
    });
    const by = y + 20;
    doc.save();
    doc.roundedRect(M, by, W, 12, 6).clip();
    let px = M;
    parts.forEach(([, v, color]) => {
      const pw = (v / totalPart) * W;
      doc.rect(px, by, pw + 0.5, 12).fill(color);
      px += pw;
    });
    doc.restore();

    // legend, laid out in a row
    let lx = M;
    const ly = by + 22;
    parts.forEach(([label, v, color]) => {
      const labelText = `${label}  ${duration(v)}`;
      doc.font(F.medium).fontSize(8.5);
      const lw = doc.widthOfString(labelText) + 22;
      if (lx + lw > M + W) return;
      doc.circle(lx + 4, ly + 4, 3.5).fill(color);
      text(labelText, lx + 13, ly, { font: 'medium', size: 8.5, color: C.body });
      lx += lw + 10;
    });
    y = ly + 26;
  }

  const ph1 = keyValues(M, y, colW, 'Speed', [
    ['Processing speed', n(perf.eventsPerSecond, ' ev/s')],
    ['Time per second of recording', n(perf.processingToRecordingRatio, ' s', 1)]
  ]);
  const ph2 = keyValues(M + colW + 36, y, colW, 'Resources', [
    ['Peak memory', n(perf.peakMemoryMB, ' MB')],
    ['Output size', n(perf.outputSizeMB, ' MB', 2)]
  ]);
  y += Math.max(ph1, ph2) + 14;

  // ======================================================================
  // Findings
  // ======================================================================
  sectionTitle('Findings', 'Calculated from the measured values above', 70);
  const LEVEL = {
    ok: { label: 'ALL CLEAR', color: C.ok, bg: C.okSoft },
    info: { label: 'GOOD TO KNOW', color: C.info, bg: C.infoSoft },
    warning: { label: 'CHECK THIS', color: C.warn, bg: C.warnSoft }
  };
  for (const finding of report.findings) {
    const lv = LEVEL[finding.level] ?? LEVEL.info;
    doc.font(F.regular).fontSize(9.5);
    const textH = doc.heightOfString(finding.text, { width: W - 34, lineGap: 2 });
    const cardH = textH + 34;
    ensure(cardH + 8);
    doc.roundedRect(M, y, W, cardH, 8).fill(C.panel);
    doc.save();
    doc.roundedRect(M, y, W, cardH, 8).clip();
    doc.rect(M, y, 4, cardH).fill(lv.color);
    doc.restore();
    text(lv.label, M + 18, y + 11, {
      font: 'bold',
      size: 7,
      color: lv.color,
      characterSpacing: 1.1
    });
    doc.font(F.regular).fontSize(9.5).fillColor(C.body);
    doc.text(finding.text, M + 18, y + 24, { width: W - 34, lineGap: 2 });
    y += cardH + 8;
  }

  // ======================================================================
  // Running header (pages 2+) and footer (all pages)
  // ======================================================================
  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);

    if (i > range.start) {
      logo(M, 28, 16);
      text('EVAA Analysis Report', M + 24, 31, {
        font: 'semibold',
        size: 9,
        color: C.ink
      });
      text(report.dataset.name || report.dataset.fileName, M, 31, {
        size: 8.5,
        color: C.muted,
        width: W,
        align: 'right'
      });
      doc.moveTo(M, 52).lineTo(M + W, 52).lineWidth(0.6).stroke(C.line);
    }

    const fy = PAGE_H - 40;
    doc.moveTo(M, fy - 10).lineTo(M + W, fy - 10).lineWidth(0.6).stroke(C.line);
    text('EVAA  ·  Event Vision Analysis  ·  Zoove Space', M, fy, {
      size: 8,
      color: C.faint
    });
    text(`Page ${i - range.start + 1} of ${range.count}`, M, fy, {
      font: 'medium',
      size: 8,
      color: C.muted,
      width: W,
      align: 'right'
    });
  }
}

// ---- charts ------------------------------------------------------------

function niceMax(v) {
  if (v <= 0) return 1;
  const exp = Math.pow(10, Math.floor(Math.log10(v)));
  const f = v / exp;
  const nice = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
  return nice * exp;
}

function drawRateChart(doc, F, box, eventRate) {
  const { x, y, w, h } = box;
  const bins = eventRate.on.length;
  const perSecond = 1e6 / (eventRate.binUs || 1);
  const on = eventRate.on.map((v) => v * perSecond);
  const off = eventRate.off.map((v) => v * perSecond);
  const top = niceMax(Math.max(...on, ...off, 1));

  const padL = 44;
  const padB = 20;
  const px = x + padL;
  const pw = w - padL - 4;
  const ph = h - padB - 6;
  const py = y + 6;

  // grid + y labels
  for (let i = 0; i <= 4; i++) {
    const gy = py + ph - (ph * i) / 4;
    doc.moveTo(px, gy).lineTo(px + pw, gy).lineWidth(0.5).stroke(i === 0 ? C.faint : C.line);
    doc.font(F.regular).fontSize(7.5).fillColor(C.muted);
    doc.text(compact((top * i) / 4), x, gy - 4, {
      width: padL - 8,
      align: 'right',
      lineBreak: false
    });
  }

  const point = (i, v) => [
    px + (bins === 1 ? 0 : (pw * i) / (bins - 1)),
    py + ph - (clamp(v / top, 0, 1) * ph)
  ];

  // ON area + lines
  doc.save();
  doc.moveTo(px, py + ph);
  on.forEach((v, i) => {
    const [ax, ay] = point(i, v);
    doc.lineTo(ax, ay);
  });
  doc.lineTo(px + pw, py + ph).closePath().fillOpacity(0.14).fill(C.accent);
  doc.restore();

  const line = (series, color) => {
    doc.save();
    series.forEach((v, i) => {
      const [ax, ay] = point(i, v);
      if (i === 0) doc.moveTo(ax, ay);
      else doc.lineTo(ax, ay);
    });
    doc.lineWidth(1.4).lineJoin('round').stroke(color);
    doc.restore();
  };
  line(on, C.accent);
  line(off, C.blue);

  // x labels: start and end of the recording
  const totalSeconds = (eventRate.binUs * bins) / 1e6;
  doc.font(F.regular).fontSize(7.5).fillColor(C.muted);
  doc.text('0', px, py + ph + 6, { lineBreak: false });
  doc.text(duration(totalSeconds), px, py + ph + 6, {
    width: pw,
    align: 'right',
    lineBreak: false
  });

  // legend
  const lx = px + pw - 92;
  doc.circle(lx, py + 8, 3).fill(C.accent);
  doc.font(F.medium).fontSize(8).fillColor(C.body).text('ON', lx + 8, py + 4, { lineBreak: false });
  doc.circle(lx + 38, py + 8, 3).fill(C.blue);
  doc.font(F.medium).fontSize(8).fillColor(C.body).text('OFF', lx + 46, py + 4, { lineBreak: false });
}

// density colour ramp: pale -> orange -> deep red-brown
const RAMP = [
  [0, [241, 245, 249]],
  [0.25, [254, 215, 170]],
  [0.55, [251, 146, 60]],
  [0.8, [194, 65, 12]],
  [1, [124, 45, 18]]
];

function heatColor(tv) {
  const v = clamp(tv, 0, 1);
  for (let i = 1; i < RAMP.length; i++) {
    if (v <= RAMP[i][0]) {
      const [t0, c0] = RAMP[i - 1];
      const [t1, c1] = RAMP[i];
      const f = (v - t0) / (t1 - t0 || 1);
      const rgb = c0.map((c, k) => Math.round(c + (c1[k] - c) * f));
      return `#${rgb.map((c) => c.toString(16).padStart(2, '0')).join('')}`;
    }
  }
  return '#7C2D12';
}

function drawHeatmap(doc, box, heat) {
  const { x, y, w, h } = box;
  const cw = w / heat.gridW;
  const ch = h / heat.gridH;
  const max = heat.max || 1;

  doc.save();
  doc.roundedRect(x, y, w, h, 6).clip();
  doc.rect(x, y, w, h).fill(heatColor(0));
  for (let gy = 0; gy < heat.gridH; gy++) {
    for (let gx = 0; gx < heat.gridW; gx++) {
      const v = heat.values[gy * heat.gridW + gx];
      if (!v) continue;
      // square root so quiet areas stay visible next to busy ones
      doc.rect(x + gx * cw, y + gy * ch, cw + 0.4, ch + 0.4).fill(heatColor(Math.sqrt(v / max)));
    }
  }
  doc.restore();
  doc.roundedRect(x, y, w, h, 6).lineWidth(0.6).stroke(C.line);
}