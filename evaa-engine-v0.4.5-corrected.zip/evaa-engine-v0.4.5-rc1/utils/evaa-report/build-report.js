/*
 * Builds the analysis report of one dataset.
 *
 * Input: a dataset as the EVAA backend returns it, i.e. an object with
 *   id, name, fileName, fileFormat, createdAt
 *   metadata: { eventCount, sensorWidth, sensorHeight, eventRate,
 *               customMetadata: { durationUs, skippedRows, timestampUnit,
 *                                 benchmark, report } }
 * where customMetadata.report is the metadata report that ingest() returns
 * (evaa-engine 0.4.4+) and customMetadata.benchmark is ingest()'s benchmark.
 *
 * It only reads those saved numbers. It never reads the data files again,
 * so it is cheap. Every value is either measured or null ("not measured").
 * Nothing is estimated or invented, and no AI is involved.
 */

const num = (v) => {
  if (v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : null;
};

const round = (v, digits = 2) => {
  if (v === null) return null;
  const f = 10 ** digits;
  return Math.round(v * f) / f;
};

const rec = (v) =>
  v && typeof v === 'object' && !Array.isArray(v) ? v : {};

const fmt = (n) => n.toLocaleString('en-US');

const msToSeconds = (ms) => (ms === null ? null : ms / 1000);

export function buildAnalysisReport(dataset, now = new Date()) {
  const meta = rec(dataset?.metadata);
  const custom = rec(meta.customMetadata);
  const report = rec(custom.report);
  const detailed = Object.keys(report).length > 0;

  const sensorR = rec(report.sensor);
  const timeR = rec(report.timestamps);
  const polR = rec(report.polarity);
  const analyticsR = rec(report.analytics);
  const qualityR = rec(report.dataQuality);
  const perfR = rec(report.performance);
  const bench = rec(custom.benchmark);

  // ---- summary -------------------------------------------------------
  const eventCount = num(report.eventCount) ?? num(meta.eventCount);
  const width = num(sensorR.width) ?? num(meta.sensorWidth);
  const height = num(sensorR.height) ?? num(meta.sensorHeight);
  const durationSeconds =
    num(timeR.durationSeconds) ??
    (num(custom.durationUs) !== null ? num(custom.durationUs) / 1e6 : null);
  const rate = num(analyticsR.eventRatePerSecond) ?? num(meta.eventRate);

  let resolutionSource = null;
  if (detailed) {
    resolutionSource =
      sensorR.resolutionVerified === true
        ? 'verified'
        : sensorR.resolutionSource === 'provided'
          ? 'provided'
          : 'estimated';
  }

  // ---- quality -------------------------------------------------------
  const validEvents = num(report.validEventCount);
  const invalidEvents = num(report.invalidEventCount);
  const total =
    validEvents !== null && invalidEvents !== null
      ? validEvents + invalidEvents
      : null;
  const completeness =
    total && total > 0 ? (validEvents / total) * 100 : null;
  const skippedRows = num(custom.skippedRows) ?? (detailed ? 0 : null);

  let ordering = null;
  if (typeof timeR.sortedInput === 'boolean') {
    ordering = timeR.sortedInput
      ? 'In time order'
      : 'Not in time order (sorted during conversion)';
  }

  // ---- sensor --------------------------------------------------------
  const activePixels = num(sensorR.activePixelCount);
  const sensorPixels =
    num(sensorR.sensorPixelCount) ??
    (width !== null && height !== null ? width * height : null);
  const coverage = num(analyticsR.spatialCoveragePercent);

  const positive = num(polR.positiveEventCount);
  const negative = num(polR.negativeEventCount);
  const zero = num(polR.zeroPolarityCount);
  let onEvents = null;
  let offEvents = null;
  let polarityNote = null;
  if (positive !== null) {
    onEvents = positive;
    offEvents = (negative ?? 0) + (zero ?? 0);
    polarityNote =
      (negative ?? 0) > 0
        ? 'Polarity is stored as +1 / -1'
        : 'Polarity is stored as 1 (ON) / 0 (OFF)';
  }
  const polarityTotal =
    onEvents !== null && offEvents !== null ? onEvents + offEvents : null;

  // ---- performance ---------------------------------------------------
  const processingMs =
    num(perfR.totalIngestionDurationMs) ?? num(rec(bench.total).durationMs);
  const processingSeconds = msToSeconds(processingMs);
  const out = rec(bench.outputFiles);
  const outputSize =
    num(out.hdf5MB) !== null || num(out.parquetMB) !== null
      ? (num(out.hdf5MB) ?? 0) + (num(out.parquetMB) ?? 0)
      : null;

  const result = {
    generatedAt: now.toISOString(),
    detailed,
    dataset: {
      id: String(dataset?.id ?? ''),
      name: String(dataset?.name ?? ''),
      fileName: String(dataset?.fileName ?? ''),
      format: String(dataset?.fileFormat ?? ''),
      uploadedAt: dataset?.createdAt
        ? new Date(dataset.createdAt).toISOString()
        : null
    },
    summary: {
      eventCount,
      sensorWidth: width,
      sensorHeight: height,
      resolutionSource,
      durationSeconds: round(durationSeconds, 6),
      timestampUnit:
        typeof timeR.unit === 'string'
          ? timeR.unit
          : typeof custom.timestampUnit === 'string'
            ? custom.timestampUnit
            : null,
      averageRateEventsPerSecond: round(rate, 0)
    },
    quality: {
      validationStatus:
        typeof qualityR.status === 'string' ? qualityR.status : null,
      validEvents,
      invalidEvents,
      skippedRows,
      completenessPercent: round(completeness, 2),
      timestampOrdering: ordering
    },
    sensor: {
      activePixels,
      sensorPixels,
      coveragePercent: round(coverage, 2),
      sparsityPercent: coverage !== null ? round(100 - coverage, 2) : null,
      eventsPerActivePixel:
        eventCount !== null && activePixels
          ? round(eventCount / activePixels, 2)
          : null,
      onEvents,
      offEvents,
      onPercent:
        onEvents !== null && polarityTotal
          ? round((onEvents / polarityTotal) * 100, 1)
          : null,
      polarityNote
    },
    performance: {
      processingSeconds: round(processingSeconds, 2),
      eventsPerSecond: round(
        num(perfR.eventsProcessedPerSecond) ??
          num(rec(bench.total).eventsPerSecond),
        0
      ),
      processingToRecordingRatio:
        processingSeconds !== null && durationSeconds
          ? round(processingSeconds / durationSeconds, 1)
          : null,
      peakMemoryMB: round(num(rec(bench.memory).peakMB), 0),
      outputSizeMB: round(outputSize, 2),
      stages: {
        readingSeconds: round(msToSeconds(num(perfR.parsingDurationMs)), 2),
        hdf5Seconds: round(msToSeconds(num(perfR.hdf5WritingDurationMs)), 2),
        parquetSeconds: round(
          msToSeconds(num(perfR.parquetWritingDurationMs)),
          2
        )
      }
    },
    findings: []
  };

  result.findings = buildFindings(result);
  return result;
}

/*
 * Plain statements that follow directly from the measured numbers.
 * level: 'ok' (nothing to do), 'info' (good to know), 'warning' (check this).
 */
function buildFindings(r) {
  const f = [];

  if (!r.detailed) {
    f.push({
      level: 'info',
      text: 'This dataset was converted before the detailed metadata existed, so some values are not available. Upload the file again to get the complete report.'
    });
  }

  if ((r.quality.invalidEvents ?? 0) > 0) {
    const all = (r.quality.validEvents ?? 0) + r.quality.invalidEvents;
    const pct = all ? ((r.quality.invalidEvents / all) * 100).toFixed(2) : '0';
    f.push({
      level: 'warning',
      text: `${fmt(r.quality.invalidEvents)} events (${pct}%) were excluded as invalid. Check the source file for corrupted values.`
    });
  }

  if ((r.quality.skippedRows ?? 0) > 0) {
    f.push({
      level: 'warning',
      text: `${fmt(r.quality.skippedRows)} rows could not be read and were skipped during conversion.`
    });
  }

  if (r.quality.timestampOrdering?.startsWith('Not in time order')) {
    f.push({
      level: 'info',
      text: 'The timestamps in the source file were not in time order. The converted files are sorted.'
    });
  }

  if (r.summary.resolutionSource === 'estimated') {
    f.push({
      level: 'info',
      text: `The sensor size (${r.summary.sensorWidth} x ${r.summary.sensorHeight}) was estimated from the largest x and y values in the data. Spatial coverage may differ for the real sensor.`
    });
  }

  if (r.sensor.coveragePercent !== null && r.sensor.coveragePercent < 5) {
    f.push({
      level: 'info',
      text: `Only ${r.sensor.coveragePercent}% of the pixels recorded events, so the activity is concentrated on a small part of the sensor.`
    });
  }

  if (f.length === 0) {
    f.push({
      level: 'ok',
      text: 'No issues were found. All events were valid and the timestamps were in order.'
    });
  }

  return f;
}