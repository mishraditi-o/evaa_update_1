const MAX_COORDINATE = 65535;

// Checks every event before it is written. Parsers already skip unreadable
// rows, so anything that reaches this point must be a clean { t, x, y, p }.
export function validateEvents(events) {
  if (!Array.isArray(events)) {
    throw new Error("Parser must return an array of events");
  }

  if (events.length === 0) {
    throw new Error("No valid events found");
  }

  for (const event of events) {
    if (
      typeof event.t !== "number" ||
      typeof event.x !== "number" ||
      typeof event.y !== "number" ||
      typeof event.p !== "number"
    ) {
      throw new Error("Invalid event. Expected { t, x, y, p }");
    }

    // NaN and Infinity are numbers in JavaScript but are never valid data.
    // Without this check a NaN timestamp would pass and break sorting.
    if (!Number.isFinite(event.t)) {
      throw new Error(
        `Invalid timestamp ${event.t}. t must be a finite number.`,
      );
    }

    if (
      !Number.isInteger(event.x) ||
      !Number.isInteger(event.y) ||
      !Number.isInteger(event.p)
    ) {
      throw new Error(
        `Invalid event (x=${event.x}, y=${event.y}, p=${event.p}). x, y and p must be whole numbers.`,
      );
    }

    if (event.p !== 0 && event.p !== 1 && event.p !== -1) {
      throw new Error(`Invalid polarity ${event.p}. p must be 0, 1 or -1.`);
    }

    if (event.x < 0 || event.y < 0) {
      throw new Error(
        `Invalid event position (${event.x}, ${event.y}). x and y must not be negative.`,
      );
    }

    if (event.x > MAX_COORDINATE || event.y > MAX_COORDINATE) {
      throw new Error(
        `Invalid event position (${event.x}, ${event.y}). x and y must be ${MAX_COORDINATE} or less.`,
      );
    }
  }

  return true;
}
