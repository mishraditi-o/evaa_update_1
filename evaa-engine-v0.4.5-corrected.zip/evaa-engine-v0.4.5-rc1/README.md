# EVAA Engine (stand-in)

Event-camera ingestion engine used by the EVAA backend. It reads raw event files, checks them, writes two standard files (HDF5 and Parquet), and can summarise a recording for charts and data-quality scores.

> **Status:** this is a stand-in engine for testing the EVAA backend end to end. The production engine comes from the Zoove data team. The backend talks to the engine through `ingest()` and `visualize()`, so the real engine can replace this one without backend changes as long as it keeps the contracts below.

## Install

```bash
npm install github:Mridul9A/evaa-engine#v0.4.3
```

Always install a release tag, never `#main`. Use the newest tag from the Releases list.

- ES module package (`"type": "module"`).
- Node 18 or newer. A CommonJS app (like the NestJS backend) can `require()` it on Node 22.12 or newer.
- Pure JavaScript and WebAssembly. No native builds, no system libraries.

## Usage

```js
import { ingest, visualize } from 'evaa-engine';

const result = await ingest('./events.csv', './out', {
  width: 640,   // optional
  height: 480,  // optional
});

const charts = await visualize('./out/data.parquet');
```

### `ingest(inputPath, outputDir, options)`

| Argument | Meaning |
| --- | --- |
| `inputPath` | Path to the input file. The format comes from the file extension. |
| `outputDir` | Folder for the output files. Created if missing. |
| `options.width`, `options.height` | Optional sensor size. If not given, it is inferred from the data (see below). |
| `options.log` | Set to `false` to silence console output. |

Return value:

```js
{
  success: true,
  eventCount: 3769468,
  metadata: {
    format, width, height, eventCount, durationUs,
    minTimestamp, maxTimestamp, timestampUnit,   // 'microseconds'
    polarityValues, eventModel, sortedInput,
    skippedRows                                   // only when rows were skipped
  },
  preview: [ { t, x, y, p }, /* first 10 events */ ],
  files: [
    { kind: 'HDF5',    path: '<outputDir>/events.h5' },
    { kind: 'PARQUET', path: '<outputDir>/data.parquet' }
  ],
  benchmark: { /* timings, peak memory, output file sizes, output checks */ }
}
```

Errors are **thrown** as `Error` with a readable message; `ingest` does not return `success: false`.

### `visualize(parquetPath, options)`

Reads the `data.parquet` file made by `ingest()` in chunks and returns binned data only, never raw events. Options: `timeBins` (default 200), `gridSize` (128), `frameCount` (20), `width`, `height`.

Returns `metadata`, `quality`, `eventRate`, `polarity`, `heatmap` and `frames`.

`quality` holds the data-quality scores:

| Field | Meaning |
| --- | --- |
| `sparsity` | Share of sensor pixels that never fired (0 to 1) |
| `density` | Events per pixel, per active pixel and per second |
| `completeness` | Share of events that are usable (finite and inside the sensor area) |
| `hotPixels` | Pixels far busier than the rest (mean + 5 standard deviations) |
| `checks` | Counts of non-finite, out-of-bounds and out-of-order events |

Per-pixel scores are skipped (`null`) for sensors above 16 million pixels.

## Data model

Every event is `{ t, x, y, p }`:

| Field | Meaning |
| --- | --- |
| `t` | Timestamp in microseconds (all formats are assumed to use microseconds) |
| `x`, `y` | Pixel coordinates (whole numbers, 0 to 65535) |
| `p` | Polarity: 0, 1 or -1 |

Conventions:
- **Sorting:** events are sorted by `t` (stable sort). If the input was unsorted, `metadata.sortedInput` is `false`.
- **Resolution:** `width = max x + 1`, `height = max y + 1`, unless `options.width` / `options.height` are passed. A small slice of a file may not reach the sensor edge, so pass the real size when you know it.
- **Duration:** `durationUs = max t - min t`.
- **Skipped rows:** rows that cannot be read (bad text, empty cells, NaN, too few columns) are skipped and counted in `metadata.skippedRows`. They are never dropped silently.

## Supported input formats

| Extension | Accepted layout |
| --- | --- |
| `.csv` | Header naming `t, x, y, p` (aliases such as `timestamp`, `pol` are accepted), or exactly 4 columns without a header. Comma, semicolon or tab separated. A BOM from Excel is ignored. |
| `.txt` | Columns separated by spaces, tabs or commas. Optional header, plain or in a `#` / `%` comment line. |
| `.npy` | N x 4 or 4 x N array (`fortran_order` handled), a structured array with fields `t, x, y, p`, or a flat array whose length is a multiple of 4. Numeric types float32/64, int8..64, uint8..64, bool. |
| `.mat` | MAT v5 (compressed files too): a struct with `x, y, p` and `t`/`ts` fields (for example `TD.x`), or an N x 4 / 4 x N numeric array. Prefers a variable named `events` or `TD`. 1-based coordinates are moved to 0-based. MAT v7.3 and big-endian files are rejected. |
| `.h5`, `.hdf5` | HDF5 with datasets `/events/t`, `/events/x`, `/events/y`, `/events/p` (the layout `ingest()` writes). |
| other | Throws `Unsupported file format: .<ext>` |

Tables that are not event data (for example a 500 x 6 array) are rejected with a clear shape error. Negative or non-integer `x`, `y`, `p`, non-finite `t`, and polarity other than 0, 1 or -1 are rejected during validation.

## Output files

| File | Contents |
| --- | --- |
| `events.h5` | HDF5 with datasets `/events/t`, `/events/x`, `/events/y`, `/events/p` |
| `data.parquet` | One Parquet file with columns `t, x, y, p`, 1,000,000 rows per row group |

After writing, both files are read back and checked (row counts, schema, first and last Parquet row). CSV, MAT and NPY versions of the same events produce identical Parquet output.

## Libraries

| Library | Used for | Notes |
| --- | --- | --- |
| `h5wasm` | Reading and writing HDF5 | WebAssembly, no native build |
| `hyparquet` | Reading Parquet | Pure JavaScript |
| `hyparquet-writer` | Writing Parquet | Pure JavaScript |
| `node:zlib` | Reading compressed MAT v5 | Built into Node |
| `express`, `multer` | Demo HTTP server (`npm start`) | Not needed by the backend |

## Performance and limits

- The whole input is read into memory as a list of events. Measured: about 290 bytes per event, so 1 million events peak at about 340 MB and a 3.77 million event file at about 1 GB.
- Run it in a worker with enough memory (2 GB or more for files of that size). Very large files need streaming, which is not built yet.
- ingest() refuses input files above 250 MB (options.maxInputBytes to change it, Infinity to switch it off). The EVAA backend allows at most 100 MB per file.
- The demo server limits uploads to 500 MB (`MAX_UPLOAD_BYTES` to change it) and deletes uploads and output after each request (`KEEP_OUTPUT=1` to keep output).

## Tests

```bash
npm test
```

Runs `tests/engine.test.js` with Node's built-in test runner. Test files are created on the fly, so no sample files are needed. If `test/Myfile.mat` exists, one extra test checks it reads as 4,257,681 events at 240 x 180.

## Not finished

- Streaming for very large files
- `benchmark()`: only parse timing, not real analysis
- Timestamp units other than microseconds (no conversion yet)
- CI

## Project layout

```
index.js                 exports ingest, benchmark, visualize
ingest/index.js          parse, validate, metadata, columns, write, verify
ingest/parser.js         picks a parser from the file extension
ingest/parsers/          csv, txt, npy, mat, h5
utils/                   metadata, validation, columns, output verification
writers/                 hdf5.writer.js, parquet.writer.js
visualize/               binned charts and data-quality scores
benchmark/               parse timing only
server.js                demo HTTP server
tests/                   automated tests
test/                    sample files and manual scripts
```

## Versioning

Releases are git tags (`v0.4.3`). The `ingest()` and `visualize()` contracts above are what the backend depends on; change them only with a new tag and a note here.

## License

To be added.
## Data semantics and verification limits

- The engine does **not** infer timestamp units from numeric magnitude. Pass `timestampUnit` as `seconds`, `milliseconds`, `microseconds`, or `nanoseconds` only when the source convention is known. Otherwise time-derived rates and normalized durations are reported as unavailable.
- `activePixelSparsity` is the fraction of pixels with zero valid events; `spatialCoverage` is the fraction with one or more valid events. Their percentages should sum to 100% when computed against the same known sensor area.
- A resolution inferred from the largest observed coordinates is an estimate, not proof of the physical sensor resolution. Supply `width` and `height` when known.
- Output verification checks HDF5 structure/dataset lengths and Parquet schema/row count plus deterministic samples across the Parquet file. It is **not** a full value-by-value verification of every HDF5 and Parquet event.
- Visualization excludes non-finite/malformed events and out-of-bounds coordinates from the plotted aggregates. `timestampUnit` should also be supplied to `visualize()` for correctly labelled time metrics.
- Ingestion is currently whole-file/in-memory and guarded by `DEFAULT_MAX_INPUT_BYTES`. Raising the limit does not make it streaming-safe; large-file streaming is a separate engineering requirement.

Example:

```js
const result = await ingest(inputPath, outputDir, {
  timestampUnit: 'microseconds', // only if guaranteed by the source
  width: 640,
  height: 480,
  resolutionVerified: true
});
```
