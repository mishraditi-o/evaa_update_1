import express from "express";
import multer from "multer";
import os from "node:os";
import path from "node:path";
import fs from "node:fs/promises";

import { ingest, visualize } from "./index.js";

const app = express();

app.use(express.json());

// The engine needs about 230 bytes of memory per event, so keep this modest.
// Override with MAX_UPLOAD_BYTES (bytes).
const MAX_UPLOAD_BYTES = Number(process.env.MAX_UPLOAD_BYTES) || 500_000_000;

// Set KEEP_OUTPUT=1 to keep the converted files on disk after /api/ingest.
const KEEP_OUTPUT = process.env.KEEP_OUTPUT === "1";

const upload = multer({
  dest: path.join(os.tmpdir(), "evaa-upload"),
  limits: { fileSize: MAX_UPLOAD_BYTES },
});

/*
 * Health check
 */
app.get("/api/status", (req, res) => {
  res.json({
    status: "success",
    message: "EVAA Engine is running",
  });
});

/*
 * Upload + ingest
 */
app.post("/api/ingest", upload.single("file"), async (req, res) => {
  let inputPath;
  let outputDir;

  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: "No file uploaded",
      });
    }

    // Multer drops the extension; put it back so the right parser is used.
    const ext = path.extname(req.file.originalname || "").toLowerCase();
    inputPath = `${req.file.path}${ext}`;
    await fs.rename(req.file.path, inputPath);

    outputDir = await fs.mkdtemp(path.join(os.tmpdir(), "evaa-output-"));

    const result = await ingest(inputPath, outputDir);

    return res.json(result);
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      error: error.message,
    });
  } finally {
    // Always remove the upload; remove the output unless asked to keep it.
    await fs.rm(inputPath ?? req.file?.path ?? "", { force: true });
    if (outputDir && !KEEP_OUTPUT) {
      await fs.rm(outputDir, { recursive: true, force: true });
    }
  }
});

/*
 * Upload a data.parquet file (made by ingest) + visualize
 * Optional form fields: timeBins, gridSize, frameCount
 */
app.post("/api/visualize", upload.single("file"), async (req, res) => {
  let parquetPath;

  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: "No file uploaded",
      });
    }

    const options = {};

    for (const key of ["timeBins", "gridSize", "frameCount"]) {
      if (req.body[key] !== undefined) {
        const value = Number(req.body[key]);

        if (!Number.isFinite(value) || value <= 0) {
          return res.status(400).json({
            success: false,
            error: `${key} must be a positive number`,
          });
        }

        options[key] = value;
      }
    }

    // visualize() checks the .parquet extension; multer drops it
    parquetPath = `${req.file.path}.parquet`;
    await fs.rename(req.file.path, parquetPath);

    const result = await visualize(parquetPath, options);

    return res.json(result);
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      error: error.message,
    });
  } finally {
    await fs.rm(parquetPath ?? req.file?.path ?? "", { force: true });
  }
});

/*
 * Upload errors (file too large, etc.) as JSON instead of an HTML page
 */
app.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    const tooLarge = error.code === "LIMIT_FILE_SIZE";

    return res.status(tooLarge ? 413 : 400).json({
      success: false,
      error: tooLarge
        ? `File is too large. Maximum is ${Math.round(MAX_UPLOAD_BYTES / 1_000_000)} MB.`
        : error.message,
    });
  }

  console.error(error);

  return res.status(500).json({
    success: false,
    error: error.message,
  });
});

export default app;
